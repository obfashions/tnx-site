import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronLeft, Loader2, Check, AlertCircle, ShieldCheck, Info } from "lucide-react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { cn } from "@/lib/utils";
import { initiateDeposit, initiateWithdraw, getTxStatus } from "@/lib/obpay.functions";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { DotWave } from "@/components/DotWave";

type Kind = "deposit" | "withdraw";


const PRESETS = [10_000, 50_000, 100_000, 250_000, 500_000, 1_000_000];

interface Limits { min: number; max: number; fee_percent?: number; fee_min?: number }
const DEF_DEP: Limits = { min: 5_000, max: 5_000_000 };
const DEF_WD: Limits = { min: 5_000, max: 2_000_000, fee_percent: 3, fee_min: 500 };

// Uganda MSISDN prefix → network. Based on public numbering plan.
function detectNetwork(raw: string): "MTN" | "AIRTEL" | null {
  const d = raw.replace(/\D/g, "");
  let local = d;
  if (local.startsWith("256")) local = "0" + local.slice(3);
  if (!local.startsWith("0")) local = "0" + local;
  if (local.length < 4) return null;
  const p = local.slice(0, 4);
  const MTN = ["0770","0771","0772","0773","0774","0775","0776","0777","0778","0779","0760","0761","0762","0763","0764","0765","0766","0767","0768","0769","0390","0391","0392","0393","0394","0395","0396","0397","0398","0399","0312","0313","0314","0315","0316","0317","0318","0319","0311","0310"];
  const AIR = ["0700","0701","0702","0703","0704","0705","0706","0707","0708","0709","0740","0741","0742","0743","0744","0745","0746","0747","0748","0749","0750","0751","0752","0753","0754","0755","0756","0757","0758","0759","0200","0201","0202","0203","0204","0205","0206","0207","0208","0209"];
  if (MTN.includes(p)) return "MTN";
  if (AIR.includes(p)) return "AIRTEL";
  return null;
}

export function MoneySheet({
  kind,
  balance,
  onClose,
  onSuccess,
}: {
  kind: Kind;
  balance: number;
  onClose: () => void;
  onSuccess?: () => void;
}) {
  const { user } = useAuth();
  const [amount, setAmount] = useState<number | "">("");
  const [mobile, setMobile] = useState("");
  const [profileName, setProfileName] = useState<string>("");
  const [holderName, setHolderName] = useState<string>("");
  const [lookingUp, setLookingUp] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [phase, setPhase] = useState<"idle" | "waiting" | "success" | "failed">("idle");
  const [reference, setReference] = useState<string | null>(null);
  const [errMsg, setErrMsg] = useState<string | null>(null);
  const [limits, setLimits] = useState<Limits>(kind === "deposit" ? DEF_DEP : DEF_WD);
  const pollTimer = useRef<number | null>(null);
  const lookupTimer = useRef<number | null>(null);

  const isDeposit = kind === "deposit";
  const min = limits.min;
  const feePct = limits.fee_percent ?? 3;
  const feeMin = limits.fee_min ?? 500;
  const calcFee = (n: number) => Math.max(feeMin, Math.round(n * (feePct / 100)));
  const network = useMemo(() => detectNetwork(mobile), [mobile]);
  const validPhone = mobile.replace(/\D/g, "").length >= 9 && !!network;

  const depositFn = useServerFn(initiateDeposit);
  const withdrawFn = useServerFn(initiateWithdraw);
  const statusFn = useServerFn(getTxStatus);

  useEffect(() => {
    const key = isDeposit ? "deposit" : "withdraw";
    supabase.from("app_settings").select("value").eq("key", key).maybeSingle().then(({ data }) => {
      if (data?.value) setLimits({ ...(isDeposit ? DEF_DEP : DEF_WD), ...(data.value as unknown as Limits) });
    });
    if (user?.id) {
      supabase.from("profiles").select("full_name, mobile").eq("id", user.id).maybeSingle().then(({ data }) => {
        if (data?.full_name) setProfileName(String(data.full_name));
        if (data?.mobile && !mobile) setMobile(String(data.mobile));
      });
    }
    return () => {
      if (pollTimer.current) window.clearTimeout(pollTimer.current);
      if (lookupTimer.current) window.clearTimeout(lookupTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDeposit, user?.id]);

  // Auto "name check": look up the account holder for this MSISDN. We check
  // our own users table first (real name, real match). If nothing is found we
  // leave the holder blank — we do NOT fabricate a name from the provider,
  // because MTN/Airtel and OBPay don't expose a public name-lookup endpoint.
  useEffect(() => {
    setHolderName("");
    if (!validPhone) return;
    if (lookupTimer.current) window.clearTimeout(lookupTimer.current);
    setLookingUp(true);
    lookupTimer.current = window.setTimeout(async () => {
      const digits = mobile.replace(/\D/g, "");
      const normalized = digits.startsWith("256") ? "+" + digits : digits.startsWith("0") ? "+256" + digits.slice(1) : "+256" + digits;
      let name = "";
      const { data } = await supabase
        .from("profiles").select("full_name").eq("mobile", normalized).maybeSingle();
      if (data?.full_name) name = String(data.full_name);
      // For deposits the number should be the signed-in user's own line — fall
      // back to their profile name so the confirmation still shows who's paying.
      else if (isDeposit && profileName) name = profileName;
      setHolderName(name);
      setLookingUp(false);
    }, 450);
  }, [mobile, validPhone, isDeposit, profileName]);


  async function pollLoop(ref: string, attempt = 0) {
    if (attempt > 40) {
      setErrMsg("Timed out waiting for confirmation. Check the Income page shortly.");
      setPhase("failed");
      return;
    }
    try {
      const res = await statusFn({ data: { reference: ref } });
      if (res.status === "success") {
        setPhase("success");
        onSuccess?.();
        return;
      }
      if (res.status === "failed") {
        setPhase("failed");
        setErrMsg(isDeposit ? "Deposit was not completed." : "Withdrawal failed.");
        return;
      }
    } catch { /* transient */ }
    pollTimer.current = window.setTimeout(() => pollLoop(ref, attempt + 1), 3000);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const n = typeof amount === "number" ? amount : 0;
    if (n < min) return toast.error(`Minimum ${isDeposit ? "deposit" : "withdrawal"} is UGX ${min.toLocaleString()}`);
    if (n > limits.max) return toast.error(`Maximum ${isDeposit ? "deposit" : "withdrawal"} is UGX ${limits.max.toLocaleString()}`);
    if (!isDeposit && n > balance) return toast.error("Amount exceeds your wallet balance");
    if (!validPhone) return toast.error("Enter a valid MTN or Airtel number");

    setSubmitting(true);
    setErrMsg(null);
    try {
      const res = await (isDeposit
        ? depositFn({ data: { amount: n, phone: mobile, network: network! } })
        : withdrawFn({ data: { amount: n, phone: mobile, network: network! } }));
      setReference(res.reference);
      setPhase("waiting");
      pollLoop(res.reference);
    } catch (e: any) {
      toast.error(e?.message || "Request failed");
      setErrMsg(e?.message || "Request failed");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex flex-col overflow-hidden bg-[#04070f] text-white">
      {/* Live dot-wave background */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(37,99,235,0.18),transparent_60%)]" />
        <DotWave />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-[#04070f] to-transparent" />
      </div>

      {/* Header */}
      <header className="relative z-10 flex items-center justify-between px-4 pt-4 pb-2">
        <button onClick={onClose} aria-label="Back" className="grid h-10 w-10 place-items-center rounded-full text-white/90 hover:bg-white/10">
          <ChevronLeft className="h-6 w-6" />
        </button>
        <h1 className="text-lg font-medium tracking-wide">{isDeposit ? "Deposit" : "Withdraw"}</h1>
        <div className="h-10 w-10" />
      </header>

      {/* Scrollable body */}
      <div className="relative z-10 flex-1 overflow-y-auto px-4 pb-40">
        {/* Method label */}
        <div className="mt-2">
          <div className="rounded-2xl border border-sky-400 bg-sky-400/10 px-4 py-3 text-center text-sm font-medium tracking-wide text-white shadow-[0_0_0_1px_rgba(56,189,248,0.6),0_0_20px_-4px_rgba(56,189,248,0.55)]">
            MTN / AIRTEL Mobile Money
          </div>
        </div>

        {(
          <form onSubmit={submit} className="mt-5 space-y-4">

            {/* Phone */}
            <div>
              <label className="mb-2 block text-sm font-medium text-white/80">MTN or Airtel Number</label>
              <div className="rounded-2xl bg-white p-0 shadow-[0_0_0_1px_rgba(56,189,248,0.55),0_0_18px_-6px_rgba(56,189,248,0.55)]">
                <input
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  inputMode="tel"
                  autoComplete="tel"
                  placeholder="0XXXXXXXXX  MTN or Airtel Number"
                  className="h-14 w-full rounded-2xl bg-transparent px-4 text-base text-slate-900 placeholder:text-slate-400 outline-none"
                />
              </div>
              {/* Auto-detect provider + optional holder line */}
              <div className="mt-2 flex min-h-[20px] flex-wrap items-center gap-2 text-xs">
                {!mobile ? (
                  <span className="text-white/40">{isDeposit ? "Enter your registered mobile number" : "Enter the recipient's mobile number"}</span>
                ) : validPhone && network ? (
                  <>
                    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-semibold ${network === "MTN" ? "bg-yellow-400/20 text-yellow-300" : "bg-red-500/20 text-red-300"}`}>
                      <ShieldCheck className="h-3 w-3" />
                      {network === "MTN" ? "MTN Mobile Money" : "Airtel Money"}
                    </span>
                    {lookingUp ? (
                      <><Loader2 className="h-3.5 w-3.5 animate-spin text-sky-300" /><span className="text-white/60">Checking account name…</span></>
                    ) : holderName ? (
                      <><span className="text-white/40">·</span><span className="text-emerald-300">{holderName}</span></>
                    ) : null}
                  </>
                ) : (
                  <><AlertCircle className="h-3.5 w-3.5 text-amber-400" /><span className="text-amber-300">Not a recognised MTN or Airtel prefix</span></>
                )}
              </div>

            </div>

            {/* Amount */}
            <div>
              <div className="flex overflow-hidden rounded-2xl shadow-[0_0_0_1px_rgba(56,189,248,0.55),0_0_18px_-6px_rgba(56,189,248,0.55)]">
                <input
                  type="number"
                  inputMode="numeric"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value === "" ? "" : Number(e.target.value))}
                  placeholder={isDeposit ? "Enter amount to deposit" : "Enter amount to withdraw"}
                  className="h-14 flex-1 bg-white px-4 text-base text-slate-900 placeholder:text-slate-400 outline-none"
                />
                <div className="grid min-w-[120px] place-items-center bg-sky-400 px-4 text-base font-semibold text-white">
                  UGX {typeof amount === "number" ? amount.toLocaleString() : "0.00"}
                </div>
              </div>
              <div className="mt-2 grid grid-cols-3 gap-2">
                {PRESETS.map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setAmount(p)}
                    className={cn(
                      "rounded-xl border px-2 py-2 text-xs font-medium transition-colors",
                      amount === p
                        ? "border-sky-400 bg-sky-400/10 text-sky-300"
                        : "border-white/10 bg-white/[0.03] text-white/70 hover:border-sky-400/60",
                    )}
                  >
                    {p >= 1_000_000 ? `${p / 1_000_000}M` : `${p / 1_000}K`}
                  </button>
                ))}
              </div>
              <div className="mt-2 text-[11px] text-white/50">
                Min UGX {min.toLocaleString()} · Max UGX {limits.max.toLocaleString()}
              </div>
            </div>

            {/* Fee breakdown for withdraw */}
            {!isDeposit && (
              <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4 text-xs">
                <div className="flex justify-between text-white/60"><span>Available in wallet</span><span>UGX {balance.toLocaleString()}</span></div>
                {typeof amount === "number" && amount >= min && (
                  <>
                    <div className="mt-1 flex justify-between text-white/60"><span>Fee ({feePct}%)</span><span>UGX {calcFee(amount).toLocaleString()}</span></div>
                    <div className="mt-1 flex justify-between font-medium text-white"><span>You'll receive</span><span>UGX {(amount - calcFee(amount)).toLocaleString()}</span></div>
                  </>
                )}
              </div>
            )}

            {/* Note */}
            <div className="rounded-2xl border border-sky-400/50 bg-white/[0.02] p-4 shadow-[0_0_0_1px_rgba(56,189,248,0.35)]">
              <div className="flex items-start gap-2 text-sm">
                <Info className="mt-0.5 h-4 w-4 flex-shrink-0 text-sky-300" />
                <div className="leading-snug">
                  <div className="font-semibold text-white">Note:</div>
                  <div className="text-white/70">
                    {isDeposit
                      ? "Enter the phone number you are using to pay (MTN or Airtel) to receive the company's payment prompt on your phone. Approve with your PIN."
                      : "Funds arrive on the mobile number entered above. Double-check the number — withdrawals cannot be reversed once processed."}
                  </div>
                </div>
              </div>
            </div>
          </form>
        )}
      </div>

      {/* Sticky CTA */}
      <div className="pointer-events-auto absolute inset-x-0 bottom-0 z-10 border-t border-white/5 bg-[#04070f]/85 px-4 pb-6 pt-4 backdrop-blur">
        <button
          type="button"
          onClick={submit as any}
          disabled={submitting}
          className="flex h-14 w-full items-center justify-center gap-2 rounded-2xl border border-sky-400/70 bg-transparent text-base font-semibold tracking-wide text-white shadow-[0_0_0_1px_rgba(56,189,248,0.6),0_0_24px_-6px_rgba(56,189,248,0.7)] transition active:scale-[0.98] disabled:opacity-50"
        >
          {submitting ? (<><Loader2 className="h-4 w-4 animate-spin" /> Sending request…</>) : (isDeposit ? "Deposit" : "Withdraw")}
        </button>
      </div>


      {/* Waiting overlay */}
      {phase === "waiting" && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-[#04070f]/85 px-6 text-center backdrop-blur-sm">
          <Loader2 className="h-10 w-10 animate-spin text-sky-300" />
          <p className="text-lg font-medium">
            {isDeposit ? "Check your phone" : "Processing withdrawal"}
          </p>
          <p className="max-w-xs text-sm text-white/60">
            {isDeposit
              ? "A payment prompt was sent to " + mobile + ". Enter your Mobile Money PIN to approve."
              : "We're sending UGX " + (typeof amount === "number" ? (amount - calcFee(amount)).toLocaleString() : "") + " to " + mobile + "."}
          </p>
          <p className="text-[11px] uppercase tracking-widest text-white/40">Ref {reference}</p>
        </div>
      )}

      {/* Success popup */}
      {phase === "success" && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/70 backdrop-blur-sm" onClick={onClose}>
          <div className="w-[86%] max-w-sm animate-in zoom-in-95 rounded-3xl border border-emerald-400/40 bg-[#0a1220] p-6 text-center shadow-[0_0_40px_-10px_rgba(16,185,129,0.6)]" onClick={(e) => e.stopPropagation()}>
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-emerald-400/15 text-emerald-400">
              <Check className="h-9 w-9" strokeWidth={3} />
            </div>
            <h3 className="mt-4 text-xl font-semibold">Successful</h3>
            <p className="mt-1 text-sm text-white/70">
              {isDeposit
                ? `UGX ${(typeof amount === "number" ? amount : 0).toLocaleString()} added to your wallet.`
                : `UGX ${(typeof amount === "number" ? amount - calcFee(amount) : 0).toLocaleString()} sent to ${mobile}.`}
            </p>
            <p className="mt-2 text-[11px] uppercase tracking-widest text-white/40">Ref {reference}</p>
            <button
              onClick={onClose}
              className="mt-5 h-12 w-full rounded-2xl border border-sky-400/70 text-sm font-semibold text-white shadow-[0_0_0_1px_rgba(56,189,248,0.55)]"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* Failure popup */}
      {phase === "failed" && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/70 backdrop-blur-sm" onClick={() => { setPhase("idle"); setErrMsg(null); }}>
          <div className="w-[86%] max-w-sm rounded-3xl border border-red-400/40 bg-[#0a1220] p-6 text-center" onClick={(e) => e.stopPropagation()}>
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-red-500/15 text-red-400">
              <AlertCircle className="h-9 w-9" />
            </div>
            <h3 className="mt-4 text-xl font-semibold">Not completed</h3>
            <p className="mt-1 text-sm text-white/70">{errMsg || "Please try again."}</p>
            <button
              onClick={() => { setPhase("idle"); setErrMsg(null); }}
              className="mt-5 h-12 w-full rounded-2xl border border-sky-400/70 text-sm font-semibold text-white"
            >
              Try again
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
