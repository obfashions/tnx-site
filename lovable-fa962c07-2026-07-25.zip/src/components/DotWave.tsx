import { useEffect, useRef } from "react";

/**
 * Animated wave of dots — subtle, monochrome, drifts across the viewport.
 * Renders on a canvas pinned behind page content.
 */
export function DotWave({ className = "" }: { className?: string }) {
  const ref = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let w = 0;
    let h = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const resize = () => {
      const parent = canvas.parentElement;
      if (!parent) return;
      w = parent.clientWidth;
      h = parent.clientHeight;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = w + "px";
      canvas.style.height = h + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const ro = new ResizeObserver(resize);
    if (canvas.parentElement) ro.observe(canvas.parentElement);

    const cols = 46;
    const rows = 22;
    const start = performance.now();

    const draw = (t: number) => {
      const time = (t - start) / 1000;
      ctx.clearRect(0, 0, w, h);
      const gapX = w / (cols - 1);
      const baseY = h * 0.55;
      const amp = Math.min(h * 0.28, 130);
      const rowGap = 7;

      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const x = c * gapX;
          const phase = c / cols;
          const y =
            baseY +
            Math.sin(time * 1.1 + phase * Math.PI * 3) * amp * (1 - r / rows) +
            r * rowGap;
          const alpha = 0.15 + (1 - r / rows) * 0.45;
          const size = 1.1 + (1 - r / rows) * 1.1;
          ctx.fillStyle = `rgba(30, 41, 59, ${alpha})`;
          ctx.beginPath();
          ctx.arc(x, y, size, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, []);

  return (
    <canvas
      ref={ref}
      aria-hidden
      className={"pointer-events-none absolute inset-0 h-full w-full " + className}
    />
  );
}
