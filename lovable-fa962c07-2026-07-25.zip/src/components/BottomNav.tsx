import { Link, useRouterState } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import { Home, Cpu, Users, LineChart, Headphones, User } from "lucide-react";

const items: { to: "/dashboard" | "/robots" | "/team" | "/income" | "/chat" | "/me"; label: string; Icon: typeof Home }[] = [
  { to: "/dashboard", label: "Home", Icon: Home },
  { to: "/robots", label: "Power", Icon: Cpu },
  { to: "/team", label: "Team", Icon: Users },
  { to: "/income", label: "Income", Icon: LineChart },
  { to: "/chat", label: "Support", Icon: Headphones },
  { to: "/me", label: "My", Icon: User },
];

export function BottomNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 bg-black">
      <div className="mx-auto max-w-md">
        <div className="grid grid-cols-6">
          {items.map(({ to, label, Icon }) => {
            const active = pathname === to || pathname.startsWith(to + "/");
            return (
              <Link
                key={to}
                to={to}
                className={cn(
                  "flex flex-col items-center justify-center gap-1 py-2.5",
                  active ? "text-sky-400" : "text-white/85",
                )}
              >
                <Icon className="h-5 w-5" strokeWidth={active ? 2.4 : 2} />
                <span className="text-[0.68rem] font-medium">{label}</span>
              </Link>
            );
          })}
        </div>
        <div className="h-[max(env(safe-area-inset-bottom),0.25rem)]" />
      </div>
    </nav>
  );
}
