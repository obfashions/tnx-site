import { useEffect, useState } from "react";
import { X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

const FALLBACK_URL = "https://chat.whatsapp.com/YOUR-INVITE-CODE";

interface WelcomeCfg {
  title?: string;
  body?: string;
  whatsapp_url?: string;
  enabled?: boolean;
}

export function WelcomePopup() {
  const [open, setOpen] = useState(false);
  const [cfg, setCfg] = useState<WelcomeCfg>({});

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (sessionStorage.getItem("tnx_welcome_shown") === "1") return;
    if (sessionStorage.getItem("tnx_just_authed") !== "1") return;
    sessionStorage.removeItem("tnx_just_authed");
    sessionStorage.setItem("tnx_welcome_shown", "1");

    Promise.all([
      supabase.from("app_settings").select("value").eq("key", "welcome_popup").maybeSingle(),
      supabase.from("app_settings").select("value").eq("key", "whatsapp_group_url").maybeSingle(),
    ]).then(([popup, wa]) => {
      const c: WelcomeCfg = (popup.data?.value as WelcomeCfg) ?? {};
      const url = (wa.data?.value as { url?: string })?.url ?? c.whatsapp_url ?? FALLBACK_URL;
      setCfg({ ...c, whatsapp_url: url });
      if (c.enabled !== false) {
        setTimeout(() => setOpen(true), 250);
      }
    });
  }, []);

  if (!open) return null;

  const now = new Date();
  const stamp = `${String(now.getDate()).padStart(2, "0")}/${String(now.getMonth() + 1).padStart(2, "0")}/${now.getFullYear()} ${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;

  const title = cfg.title || "🚀 W Series Machines Now Available!";
  const intro = "✨ W Series - Powerful Investment with High Returns!";
  const specs = [
    ["Price", "50,000 UGX"],
    ["Lock", "25 Days"],
    ["Limit", "20"],
    ["Total Income", "375,000 UGX"],
    ["Purchase Reward", "2,500 UGX"],
  ];
  const outro = "For every 1 new member you successfully invite to use the W-1 machine, you will instantly receive a 5,000 UGX invitation reward.";

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 px-5 py-8" onClick={() => setOpen(false)}>
      <div className="relative w-full max-w-sm rounded-xl bg-white p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <button aria-label="Close" onClick={() => setOpen(false)} className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-md border border-neutral-400 text-neutral-800 hover:bg-neutral-100">
          <X className="h-4 w-4" strokeWidth={2.5} />
        </button>
        <h2 className="pr-8 font-serif text-[24px] font-bold leading-[1.15] text-neutral-900">{title}</h2>
        <p className="mt-2 text-right text-[13px] text-neutral-400">{stamp}</p>

        {cfg.body ? (
          <div className="mt-3 whitespace-pre-line font-serif text-[16px] font-bold leading-snug text-neutral-900">{cfg.body}</div>
        ) : (
          <div className="mt-2 space-y-3 font-serif text-neutral-900">
            <p className="text-[17px] font-bold leading-snug">{intro}</p>
            <div className="text-[17px] font-bold leading-[1.35]">
              <p className="flex items-center gap-1.5">
                <span className="grid h-5 w-5 place-items-center rounded-sm bg-[#22C55E] text-white text-[13px]">✓</span>
                <span>W-1 Machine:</span>
              </p>
              {specs.map(([k, v]) => (
                <p key={k}>{k}: {v}</p>
              ))}
            </div>
            <p className="text-[17px] font-bold leading-snug">{outro}</p>
          </div>
        )}

        <div className="mt-5 flex items-center justify-between">
          <a href={cfg.whatsapp_url || FALLBACK_URL} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-[17px] font-semibold text-[#1E90FF]">
            <span className="text-xl">💬</span> Message
          </a>
          <button onClick={() => setOpen(false)} className="text-[17px] font-semibold text-[#1E90FF]">
            More
          </button>
        </div>
      </div>
    </div>
  );
}

