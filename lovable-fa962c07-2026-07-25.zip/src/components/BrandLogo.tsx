import { cn } from "@/lib/utils";
import brandMark from "@/assets/brand-mark.jpg";

export function BrandLogo({ className, size = "md" }: { className?: string; size?: "sm" | "md" | "lg" }) {
  const dims = size === "lg" ? "h-14 w-14" : size === "sm" ? "h-10 w-10" : "h-12 w-12";
  const text = size === "lg" ? "text-2xl" : size === "sm" ? "text-[0.95rem]" : "text-lg";
  const tag = size === "lg" ? "text-[0.7rem]" : "text-[0.55rem]";
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <div className={cn("relative overflow-hidden rounded-2xl bg-white shadow-elegant ring-1 ring-primary/30", dims)}>
        <img
          src={brandMark}
          alt="TNX humanoid robot"
          loading="lazy"
          className="h-full w-full object-cover"
        />
        <span className="absolute -bottom-0.5 right-1 h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_6px_2px_rgba(52,211,153,0.7)]" />
      </div>
      <div className="flex flex-col leading-none">
        <span className={cn("font-display font-medium uppercase tracking-tight text-foreground", text)}>
          TNX <span className="text-primary">Robots</span>
        </span>
        <span className={cn("mt-1 font-normal uppercase tracking-[0.28em] text-muted-foreground", tag)}>
          AI · Uganda
        </span>
      </div>
    </div>
  );
}
