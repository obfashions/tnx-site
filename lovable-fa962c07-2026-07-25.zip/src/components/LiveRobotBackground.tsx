import factoryImg from "@/assets/factory-robots.jpg";

export function LiveRobotBackground({ className = "" }: { className?: string }) {
  return (
    <div aria-hidden className={"pointer-events-none absolute inset-0 overflow-hidden " + className}>
      <img
        src={factoryImg}
        alt=""
        className="absolute inset-0 h-full w-full object-cover"
      />
      {/* Blue tint + vignette */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#050914] via-[#050914]/40 to-transparent" />
      <div className="absolute inset-0 bg-primary/10 mix-blend-overlay" />
      {/* Scanning line */}
      <div className="absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-transparent via-primary/70 to-transparent animate-scan" />
    </div>
  );
}
