// Server-side helpers that pull plan pricing and withdraw/deposit config
// from the DB (admin-editable via /admin/settings). Client screens read
// from Supabase directly with react-query; keep this file server-only.

import { supabaseAdmin } from "@/integrations/supabase/client.server";

export interface WithdrawSettings {
  min: number;
  max: number;
  fee_percent: number;
  fee_min: number;
}

export interface DepositSettings {
  min: number;
  max: number;
}

const DEFAULT_WITHDRAW: WithdrawSettings = { min: 5000, max: 2_000_000, fee_percent: 3, fee_min: 500 };
const DEFAULT_DEPOSIT: DepositSettings = { min: 5000, max: 5_000_000 };

export async function getWithdrawSettings(): Promise<WithdrawSettings> {
  const { data } = await supabaseAdmin.from("app_settings").select("value").eq("key", "withdraw").maybeSingle();
  const v = (data?.value ?? {}) as Partial<WithdrawSettings>;
  return { ...DEFAULT_WITHDRAW, ...v };
}

export async function getDepositSettings(): Promise<DepositSettings> {
  const { data } = await supabaseAdmin.from("app_settings").select("value").eq("key", "deposit").maybeSingle();
  const v = (data?.value ?? {}) as Partial<DepositSettings>;
  return { ...DEFAULT_DEPOSIT, ...v };
}

export function calcWithdrawFee(amount: number, s: WithdrawSettings): number {
  return Math.max(s.fee_min, Math.round(amount * (s.fee_percent / 100)));
}

export async function getPlanPrice(id: string): Promise<number | null> {
  const { data } = await supabaseAdmin
    .from("investment_plans")
    .select("price, active")
    .eq("id", id)
    .maybeSingle();
  if (!data || !data.active) return null;
  return Number(data.price);
}
