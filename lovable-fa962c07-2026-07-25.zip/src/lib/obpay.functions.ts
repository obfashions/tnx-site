import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  getWithdrawSettings,
  getDepositSettings,
  calcWithdrawFee,
} from "@/lib/plans-data";


const OBPAY_URL =
  "https://k5nkqygnd0i42zb1n5c3.helloreaddy.com/functions/v1/obpay-api-no-jwt";
const OBPAY_PUBLIC_KEY = "sb_publishable_dFKnLJZfWkXfRVr9l97rEm5s8RweReFt";

function normalizePhone(raw: string): string {
  const d = raw.replace(/\D/g, "");
  if (d.startsWith("256")) return "+" + d;
  if (d.startsWith("0")) return "+256" + d.slice(1);
  if (d.length === 9) return "+256" + d;
  return "+" + d;
}

async function callObPay(body: Record<string, unknown>) {
  const key = process.env.OBPAY_SECRET_KEY;
  if (!key) throw new Error("OBPAY_SECRET_KEY missing on server");
  const res = await fetch(OBPAY_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-API-Key": key,
      Authorization: `Bearer ${OBPAY_PUBLIC_KEY}`,
      apikey: OBPAY_PUBLIC_KEY,
    },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  let json: any = null;
  try { json = text ? JSON.parse(text) : null; } catch { /* keep text */ }
  if (!res.ok || (json && json.success === false)) {
    const msg = json?.error || json?.message || text || `HTTP ${res.status}`;
    throw new Error(String(msg));
  }
  return json;
}

const initiateSchema = z.object({
  amount: z.number().int().positive().min(500),
  phone: z.string().min(9),
  network: z.enum(["MTN", "AIRTEL"]).optional(),
});

export const initiateDeposit = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => initiateSchema.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const phone = normalizePhone(data.phone);

    const limits = await getDepositSettings();
    if (data.amount < limits.min) throw new Error(`Minimum deposit is UGX ${limits.min.toLocaleString()}`);
    if (data.amount > limits.max) throw new Error(`Maximum deposit is UGX ${limits.max.toLocaleString()}`);

    const reference = `DEP-${userId.slice(0, 8)}-${Date.now()}`;

    const { error: insErr } = await supabase.from("transactions").insert({
      user_id: userId,
      type: "deposit",
      amount: data.amount,
      currency: "UGX",
      phone,
      network: data.network,
      reference,
      status: "pending",
      description: "Wallet deposit via OBPay",
    });
    if (insErr) throw new Error(insErr.message);

    try {
      const resp = await callObPay({
        _action: "collect",
        phoneNumber: phone,
        amount: data.amount,
        currency: "UGX",
        reference,
        description: "TNX deposit",
        ...(data.network ? { network: data.network } : {}),
      });
      const txId = resp?.data?.transaction_id;
      if (txId) {
        await supabase.from("transactions").update({ obpay_transaction_id: txId }).eq("reference", reference);
      }
      return { reference, status: "pending" as const };
    } catch (e: any) {
      await supabase.from("transactions")
        .update({ status: "failed", error_message: e.message })
        .eq("reference", reference);
      throw e;
    }
  });

export const initiateWithdraw = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => initiateSchema.parse(d))
  .handler(async ({ data, context }) => {
    const { userId } = context;
    const phone = normalizePhone(data.phone);

    const settings = await getWithdrawSettings();
    if (data.amount < settings.min) throw new Error(`Minimum withdrawal is UGX ${settings.min.toLocaleString()}`);
    if (data.amount > settings.max) throw new Error(`Maximum withdrawal is UGX ${settings.max.toLocaleString()}`);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: prof, error: pErr } = await supabaseAdmin
      .from("profiles").select("wallet_balance").eq("id", userId).single();
    if (pErr || !prof) throw new Error("Could not read wallet");
    const bal = Number(prof.wallet_balance || 0);
    if (bal < data.amount) throw new Error("Insufficient wallet balance");

    const reference = `WD-${userId.slice(0, 8)}-${Date.now()}`;
    const fee = calcWithdrawFee(data.amount, settings);
    const netAmount = data.amount - fee;

    const { error: debErr } = await supabaseAdmin
      .from("profiles")
      .update({ wallet_balance: bal - data.amount })
      .eq("id", userId)
      .eq("wallet_balance", bal);
    if (debErr) throw new Error("Could not hold funds — try again");

    const { error: insErr } = await supabaseAdmin.from("transactions").insert({
      user_id: userId,
      type: "withdraw",
      amount: data.amount,
      fee,
      net_amount: netAmount,
      currency: "UGX",
      phone,
      network: data.network,
      reference,
      status: "pending",
      description: `Wallet withdrawal · fee UGX ${fee.toLocaleString()}`,
    });
    if (insErr) {
      await supabaseAdmin.from("profiles").update({ wallet_balance: bal }).eq("id", userId);
      throw new Error(insErr.message);
    }

    try {
      const resp = await callObPay({
        _action: "payout",
        phoneNumber: phone,
        amount: netAmount,
        currency: "UGX",
        reference,
        description: "TNX withdrawal",
        ...(data.network ? { network: data.network } : {}),
      });
      const txId = resp?.data?.transaction_id;
      if (txId) {
        await supabaseAdmin.from("transactions").update({ obpay_transaction_id: txId }).eq("reference", reference);
      }
      return { reference, status: "pending" as const, fee, netAmount };
    } catch (e: any) {
      await supabaseAdmin.from("transactions")
        .update({ status: "failed", error_message: e.message })
        .eq("reference", reference);
      const { data: cur } = await supabaseAdmin
        .from("profiles").select("wallet_balance").eq("id", userId).single();
      await supabaseAdmin
        .from("profiles")
        .update({ wallet_balance: Number(cur?.wallet_balance || 0) + data.amount })
        .eq("id", userId);
      throw e;
    }
  });

export const investInPlan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ planId: z.string().min(1), source: z.enum(["deposit", "earnings"]).default("deposit") }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: planRow, error: planErr } = await supabaseAdmin
      .from("investment_plans")
      .select("id, code, name, price, daily, cycle_days, active")
      .eq("id", data.planId).maybeSingle();
    if (planErr || !planRow || !planRow.active) throw new Error("Unknown or inactive plan");
    const price = Number(planRow.price);
    const daily = Number(planRow.daily);
    const cycle = Number(planRow.cycle_days);

    const { data: prof, error: pErr } = await supabaseAdmin
      .from("profiles").select("wallet_balance").eq("id", userId).single();
    if (pErr || !prof) throw new Error("Could not read wallet");
    const bal = Number(prof.wallet_balance || 0);
    if (bal < price) throw new Error("Insufficient balance — top up first");

    const { error: debErr } = await supabaseAdmin
      .from("profiles")
      .update({ wallet_balance: bal - price })
      .eq("id", userId)
      .eq("wallet_balance", bal);
    if (debErr) throw new Error("Wallet changed — try again");

    const reference = `INV-${userId.slice(0, 8)}-${Date.now()}`;
    const { error: insErr } = await supabaseAdmin.from("transactions").insert({
      user_id: userId,
      type: "invest",
      amount: price,
      currency: "UGX",
      phone: "",
      reference,
      status: "success",
      description: `Machine activated: ${planRow.code} · ${planRow.name}`,
    });
    if (insErr) {
      await supabaseAdmin.from("profiles").update({ wallet_balance: bal }).eq("id", userId);
      throw new Error(insErr.message);
    }

    const endsAt = new Date(Date.now() + cycle * 86400_000).toISOString();
    const { error: invErr } = await supabaseAdmin.from("user_investments").insert({
      user_id: userId,
      plan_id: planRow.id,
      plan_name: `${planRow.code} · ${planRow.name}`,
      price,
      daily,
      cycle_days: cycle,
      ends_at: endsAt,
    });
    if (invErr) {
      // Roll back the transaction row + refund the wallet so the user isn't
      // left with a debit but no running machine.
      await supabaseAdmin.from("transactions").delete().eq("reference", reference);
      await supabaseAdmin.from("profiles").update({ wallet_balance: bal }).eq("id", userId);
      throw new Error("Could not start machine — please try again");
    }

    // Pay 3-level referral commissions (10% / 5% / 2%)
    const { error: refErr } = await supabaseAdmin.rpc("pay_referral_commissions", {
      _user_id: userId,
      _amount: price,
      _source_ref: reference,
    });
    if (refErr) console.error("pay_referral_commissions failed", refErr);

    return { reference, price, newBalance: bal - price };
  });

export const accrueEarnings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin.rpc("accrue_user_earnings", { _user_id: context.userId });
    if (error) throw new Error(error.message);
    const row = Array.isArray(data) ? data[0] : data;
    return { credited: Number(row?.credited || 0), days: Number(row?.days_credited || 0) };
  });



export const getTxStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ reference: z.string().min(3) }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: row, error } = await supabase
      .from("transactions").select("*")
      .eq("reference", data.reference).eq("user_id", userId).single();
    if (error || !row) throw new Error("Transaction not found");
    if (row.status !== "pending") {
      return { status: row.status as "success" | "failed", amount: Number(row.amount), type: row.type };
    }

    let resp: any;
    try {
      resp = await callObPay({ _action: "transaction-status", reference: data.reference });
    } catch {
      return { status: "pending" as const, amount: Number(row.amount), type: row.type };
    }
    const upstream = resp?.data?.status as string | undefined;
    if (!upstream || upstream === "pending") {
      return { status: "pending" as const, amount: Number(row.amount), type: row.type };
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const isSuccess = upstream === "success" || upstream === "completed";
    const finalStatus: "success" | "failed" = isSuccess ? "success" : "failed";

    const patch: any = {
      status: finalStatus,
      obpay_transaction_id: resp?.data?.id ?? row.obpay_transaction_id,
    };
    if (resp?.data?.fee_amount != null) patch.fee = resp.data.fee_amount;
    if (resp?.data?.net_amount != null) patch.net_amount = resp.data.net_amount;

    const { data: upd, error: uErr } = await supabaseAdmin
      .from("transactions")
      .update(patch)
      .eq("reference", data.reference)
      .eq("status", "pending")
      .select("id, type, amount")
      .maybeSingle();

    if (uErr) throw new Error(uErr.message);

    if (upd) {
      const { data: prof } = await supabaseAdmin
        .from("profiles").select("wallet_balance").eq("id", userId).single();
      const bal = Number(prof?.wallet_balance || 0);
      if (row.type === "deposit" && finalStatus === "success") {
        await supabaseAdmin.from("profiles")
          .update({ wallet_balance: bal + Number(row.amount) }).eq("id", userId);
      } else if (row.type === "withdraw" && finalStatus === "failed") {
        await supabaseAdmin.from("profiles")
          .update({ wallet_balance: bal + Number(row.amount) }).eq("id", userId);
      }
    }

    return { status: finalStatus, amount: Number(row.amount), type: row.type };
  });
