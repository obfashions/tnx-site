import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { DotWave } from "@/components/DotWave";
import { supabase } from "@/integrations/supabase/client";
import atlasImg from "@/assets/robot-atlas.jpg";
import novaImg from "@/assets/robot-nova.jpg";
import tnxR2Img from "@/assets/robot-tnx-r2.jpg";
import anchorImg from "@/assets/robot-anchor.jpg";
import factoryImg from "@/assets/factory-robots.jpg";
import machineImg from "@/assets/machine-unit.jpg";

const IMG_POOL = [atlasImg, novaImg, tnxR2Img, anchorImg, factoryImg, machineImg];
const imgFor = (id: string, i: number) => IMG_POOL[i % IMG_POOL.length];

export const Route = createFileRoute("/_authenticated/robots/")({
  head: () => ({ meta: [{ title: "AI Machines — TNX" }] }),
  component: Page,
});

type SeriesKey = "All" | "W" | "K" | "A" | "S";

export interface Plan {
  id: string;
  series: Exclude<SeriesKey, "All">;
  code: string;
  name: string;
  lock: number;
  days: number;
  daily: number;
  price: number;
  total: number;
  img: string;
  soldOut?: boolean;
}

const TABS: { key: SeriesKey; label: string }[] = [
  { key: "All", label: "All" },
  { key: "W", label: "W series" },
  { key: "K", label: "K series" },
  { key: "A", label: "A series" },
  { key: "S", label: "S series" },
];

const NOTES: Record<Exclude<SeriesKey, "All">, string> = {
  W: "The W-Series are our workhorse mining machines. Lock period is 25 days — earnings are released daily to your income balance and can be withdrawn at the end of each cycle.",
  K: "K-Series machines run heavier compute jobs on a 30-day cycle. Higher total return, slightly longer wait. Earnings pay out daily; principal unlocks at day 30.",
  A: "With A-Series Machines (A-1 to A-6), you earn machine income daily and can withdraw your earnings immediately, without waiting for the investment cycle to be completed.",
  S: "S-Series are our institutional-grade machines. Currently sold out — new stock is allocated to existing S-Series holders first.",
};

export async function fetchPlans(): Promise<Plan[]> {
  const { data, error } = await supabase
    .from("investment_plans")
    .select("*")
    .eq("active", true)
    .order("sort_order", { ascending: true });
  if (error || !data) return [];
  return data.map((r, i) => ({
    id: r.id,
    series: r.series as Plan["series"],
    code: r.code,
    name: r.name,
    lock: Number(r.lock_days),
    days: Number(r.cycle_days),
    daily: Number(r.daily),
    price: Number(r.price),
    total: Number(r.total),
    img: r.image_url || imgFor(r.id, i),
    soldOut: !!r.sold_out,
  }));
}

function Page() {
  const [tab, setTab] = useState<SeriesKey>("All");
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPlans().then((p) => { setPlans(p); setLoading(false); });
  }, []);

  const list = useMemo(() => (tab === "All" ? plans : plans.filter((p) => p.series === tab)), [tab, plans]);
  const note = tab === "All"
    ? "Choose a series below. Every machine earns daily. A-Series pays out with no lock-up; W and K series release principal at the end of the cycle."
    : NOTES[tab];

  return (
    <div className="relative min-h-screen bg-white pb-24">
      <div className="pointer-events-none fixed inset-0 -z-0 opacity-60">
        <DotWave />
      </div>
      <div className="sticky top-0 z-30 bg-black text-white">
        <div className="mx-auto flex max-w-md items-center gap-3 px-4 py-3">
          <div className="grid h-8 w-8 place-items-center rounded-full bg-white/10 text-sm">🏠</div>
          <div className="flex-1 truncate rounded-full bg-white/10 px-4 py-1.5 text-xs text-white/80">
            tnx-ai.com/products
          </div>
        </div>
        <div className="mx-auto flex max-w-md gap-6 overflow-x-auto px-4 pb-2 text-sm [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {TABS.map((t) => {
            const active = tab === t.key;
            return (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={"relative shrink-0 pb-2 " + (active ? "text-sky-400" : "text-white/70")}
              >
                {t.label}
                {active && <span className="absolute inset-x-2 -bottom-0.5 h-0.5 rounded-full bg-sky-400" />}
              </button>
            );
          })}
        </div>
      </div>

      <div className="relative z-10 mx-auto max-w-md px-4">
        <div className="mt-4 rounded-md bg-slate-100 p-4 text-[0.95rem] leading-relaxed text-slate-800">
          {note}
        </div>

        <div className="mt-4 space-y-4">
          {loading && <div className="py-10 text-center text-sm text-slate-500">Loading machines…</div>}
          {!loading && list.map((p) => <PlanCard key={p.id} plan={p} />)}
          {!loading && list.length === 0 && (
            <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500">
              No machines available in this series yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function PlanCard({ plan }: { plan: Plan }) {
  const soldOut = !!plan.soldOut;
  const inner = (
    <div className="flex items-stretch gap-3 rounded-xl border border-sky-300 bg-white p-2 shadow-[0_1px_0_rgba(0,0,0,0.02)]">
      <div className="relative h-[112px] w-[132px] shrink-0 overflow-hidden rounded-lg bg-black">
        <img src={plan.img} alt={plan.code} className="h-full w-full object-cover" loading="lazy" />
        {soldOut && (
          <div className="absolute inset-0 grid place-items-center bg-black/60">
            <span className="rotate-[-14deg] rounded border border-red-400 px-2 py-0.5 text-[0.7rem] font-medium uppercase tracking-wider text-red-300">
              Sold Out
            </span>
          </div>
        )}
      </div>
      <div className="min-w-0 flex-1 py-1">
        <div className="flex items-baseline gap-2">
          <p className="text-lg font-medium text-sky-500">{plan.code}</p>
          <p className="truncate text-[0.72rem] font-normal text-slate-500">{plan.name}</p>
        </div>
        <p className="mt-0.5 text-[0.85rem] text-slate-800">
          Lock: {plan.lock === 0 ? "No lock" : `${plan.lock} Days`} · Runs {plan.days}d
        </p>
        <p className="text-[0.85rem] text-slate-800">Price: UGX {plan.price.toLocaleString()}</p>
        <p className="text-[0.85rem] text-slate-800">
          Daily: <span className="font-medium text-emerald-600">UGX {plan.daily.toLocaleString()}</span>
        </p>
        <p className="text-[0.85rem] text-slate-800">
          Total: <span className="font-medium text-emerald-600">UGX {plan.total.toLocaleString()}</span>
        </p>
      </div>
    </div>
  );

  if (soldOut) return <div className="opacity-90">{inner}</div>;
  return (
    <Link to="/robots/$id" params={{ id: plan.id }} className="block active:opacity-90">
      {inner}
    </Link>
  );
}
