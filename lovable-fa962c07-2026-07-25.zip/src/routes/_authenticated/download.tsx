import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { ChevronLeft, Share2, Smartphone } from "lucide-react";

export const Route = createFileRoute("/_authenticated/download")({
  head: () => ({ meta: [{ title: "Get the app — TNX" }] }),
  component: Page,
});

function Page() {
  const url = typeof window !== "undefined" ? window.location.origin : "https://tnxbot.lovable.app";
  async function share() {
    try {
      if (navigator.share) await navigator.share({ title: "TNX", url });
      else { await navigator.clipboard.writeText(url); toast.success("Link copied"); }
    } catch { /* dismissed */ }
  }
  return (
    <div className="min-h-screen bg-[#f4f6fa] pb-28">
      <header className="bg-white px-5 py-4 flex items-center gap-3 border-b border-slate-100">
        <Link to="/me" className="p-1"><ChevronLeft className="h-5 w-5" /></Link>
        <h1 className="text-lg text-slate-900">Get the app</h1>
      </header>
      <section className="px-4 pt-6">
        <div className="rounded-2xl bg-white p-6 text-center ring-1 ring-slate-200">
          <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-sky-500 text-white">
            <Smartphone className="h-8 w-8" />
          </div>
          <h2 className="mt-4 text-lg text-slate-900">Install TNX on your phone</h2>
          <p className="mt-1 text-sm text-slate-500">
            Add this site to your home screen for a full-screen, app-like experience.
          </p>
        </div>
        <div className="mt-4 rounded-2xl bg-white p-4 ring-1 ring-slate-200 space-y-3 text-sm text-slate-700">
          <p className="text-slate-900">Android — Chrome</p>
          <ol className="list-decimal pl-5 space-y-1">
            <li>Tap the ⋮ menu (top-right).</li>
            <li>Choose <b>Add to Home screen</b>.</li>
            <li>Tap <b>Install</b>.</li>
          </ol>
          <p className="mt-3 text-slate-900">iPhone — Safari</p>
          <ol className="list-decimal pl-5 space-y-1">
            <li>Tap the Share icon.</li>
            <li>Scroll and pick <b>Add to Home Screen</b>.</li>
            <li>Tap <b>Add</b>.</li>
          </ol>
        </div>
        <button onClick={share}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-sky-500 py-3.5 text-white">
          <Share2 className="h-4 w-4" /> Share install link
        </button>
      </section>
    </div>
  );
}
