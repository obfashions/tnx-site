import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ChevronLeft } from "lucide-react";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({ meta: [{ title: "Settings — TNX" }] }),
  component: Page,
});

function Page() {
  const nav = useNavigate();
  const [fullName, setFullName] = useState("");
  const [mobile, setMobile] = useState("");
  const [saving, setSaving] = useState(false);
  const [uid, setUid] = useState<string | null>(null);

  const [currentPw, setCurrentPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [changingPw, setChangingPw] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      setUid(data.user.id);
      const { data: p } = await supabase.from("profiles").select("full_name, mobile").eq("id", data.user.id).maybeSingle();
      if (p) { setFullName(p.full_name ?? ""); setMobile(p.mobile ?? ""); }
    });
  }, []);

  async function save() {
    if (!uid) return;
    setSaving(true);
    const { error } = await supabase.from("profiles").update({ full_name: fullName }).eq("id", uid);
    setSaving(false);
    if (error) toast.error(error.message); else toast.success("Saved");
  }

  async function changePassword() {
    if (!currentPw) return toast.error("Enter your current password");
    if (newPw.length < 6) return toast.error("New password must be at least 6 characters");
    if (newPw !== confirmPw) return toast.error("Passwords do not match");
    const { data: u } = await supabase.auth.getUser();
    const email = u.user?.email;
    if (!email) return toast.error("Not signed in");
    setChangingPw(true);
    try {
      const { error: signErr } = await supabase.auth.signInWithPassword({ email, password: currentPw });
      if (signErr) { toast.error("Current password is incorrect"); return; }
      const { error } = await supabase.auth.updateUser({ password: newPw });
      if (error) { toast.error(error.message); return; }
      setCurrentPw(""); setNewPw(""); setConfirmPw("");
      toast.success("Password changed");
    } finally {
      setChangingPw(false);
    }
  }

  async function signOut() {
    await supabase.auth.signOut();
    nav({ to: "/auth", replace: true });
  }

  return (
    <div className="min-h-screen bg-[#f4f6fa] pb-28">
      <header className="bg-white px-5 py-4 flex items-center gap-3 border-b border-slate-100">
        <Link to="/me" className="p-1"><ChevronLeft className="h-5 w-5" /></Link>
        <h1 className="text-lg text-slate-900">Settings</h1>
      </header>
      <section className="px-4 pt-4 space-y-4">
        <div className="rounded-2xl bg-white p-4 ring-1 ring-slate-200 space-y-3">
          <label className="block">
            <span className="text-xs text-slate-500">Full name</span>
            <input value={fullName} onChange={(e) => setFullName(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm" />
          </label>
          <label className="block">
            <span className="text-xs text-slate-500">Mobile (locked)</span>
            <input value={mobile} disabled
              className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-500" />
          </label>
          <button onClick={save} disabled={saving}
            className="w-full rounded-xl bg-sky-500 py-3 text-sm text-white disabled:opacity-60">
            {saving ? "Saving…" : "Save profile"}
          </button>
        </div>

        <div className="rounded-2xl bg-white p-4 ring-1 ring-slate-200 space-y-3">
          <div className="text-sm text-slate-900">Change password</div>
          <label className="block">
            <span className="text-xs text-slate-500">Current password</span>
            <input type="password" value={currentPw} onChange={(e) => setCurrentPw(e.target.value)} autoComplete="current-password"
              className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm" />
          </label>
          <label className="block">
            <span className="text-xs text-slate-500">New password</span>
            <input type="password" value={newPw} onChange={(e) => setNewPw(e.target.value)} autoComplete="new-password"
              className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm" />
          </label>
          <label className="block">
            <span className="text-xs text-slate-500">Confirm new password</span>
            <input type="password" value={confirmPw} onChange={(e) => setConfirmPw(e.target.value)} autoComplete="new-password"
              className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm" />
          </label>
          <button onClick={changePassword} disabled={changingPw}
            className="w-full rounded-xl bg-slate-900 py-3 text-sm text-white disabled:opacity-60">
            {changingPw ? "Updating…" : "Update password"}
          </button>
        </div>

        <div className="rounded-2xl bg-white p-4 ring-1 ring-slate-200 divide-y divide-slate-100">
          <Link to="/team" className="flex items-center justify-between py-3 text-sm text-slate-800">Referral & team <span className="text-slate-400">›</span></Link>
          <Link to="/income" className="flex items-center justify-between py-3 text-sm text-slate-800">Transaction history <span className="text-slate-400">›</span></Link>
          <Link to="/chat" className="flex items-center justify-between py-3 text-sm text-slate-800">Contact support <span className="text-slate-400">›</span></Link>
        </div>

        <button onClick={signOut}
          className="w-full rounded-2xl border border-red-200 bg-white py-3.5 text-sm text-red-600">Sign out</button>
      </section>
    </div>
  );
}
