import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Wallet, TrendingUp, Clock, Coins, ShieldCheck, Zap, Check, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { fetchPlans, type Plan } from "./robots.index";
import { investInPlan } from "@/lib/obpay.functions";


export const Route = createFileRoute("/_authenticated/robots/$id")({
  head: ({ params }) => ({
    meta: [{ title: `Machine ${params.id.toUpperCase()} — TNX` }],
  }),
  component: PlanDetail,
});

function PlanDetail() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const [plan, setPlan] = useState<Plan | null>(null);
  const [loading, setLoading] = useState(true);

  const [source, setSource] = useState<"deposit" | "earnings">("deposit");
  const [submitting, setSubmitting] = useState(false);
  const [depositBalance, setDepositBalance] = useState(0);
  const [earningsBalance, setEarningsBalance] = useState(0);
  const investFn = useServerFn(investInPlan);

  async function loadBalance() {
    const { data } = await supabase.auth.getUser();
    if (!data.user) return;
    const uid = data.user.id;
    const { data: row } = await supabase
      .from("profiles").select("wallet_balance").eq("id", uid).maybeSingle();
    if (row) setDepositBalance(Number(row.wallet_balance) || 0);
    const { data: txs } = await supabase
      .from("transactions").select("amount")
      .eq("user_id", uid).eq("type", "earning").eq("status", "success");
    const earned = (txs ?? []).reduce((s: number, t: any) => s + Number(t.amount || 0), 0);
    setEarningsBalance(earned);
  }

  useEffect(() => {
    loadBalance();
    fetchPlans().then((plans) => {
      setPlan(plans.find((p) => p.id === id) ?? null);
      setLoading(false);
    });
  }, [id]);

  if (loading) {
    return <div className="grid min-h-screen place-items-center bg-white"><Loader2 className="h-6 w-6 animate-spin text-sky-500" /></div>;
  }

  if (!plan) {
    return (
      <div className="grid min-h-screen place-items-center p-6 text-center">
        <div>
          <p className="text-lg font-medium">Machine not found</p>
          <Link to="/robots" className="mt-3 inline-block text-sky-500">Back to machines</Link>
        </div>
      </div>
    );
  }

  const daily = plan.daily;
  const profit = plan.total - plan.price;
  const roi = Math.round((profit / plan.price) * 100);
  const available = source === "deposit" ? depositBalance : earningsBalance;

  async function invest() {
    if (available < plan!.price) {
      toast.error(
        source === "deposit"
          ? "Your deposit balance is too low. Top up first, then try again."
          : "Not enough earnings balance yet. Withdraw daily income for a few more days.",
      );
      return;
    }
    setSubmitting(true);
    try {
      await investFn({ data: { planId: plan!.id, source } });
      await loadBalance();
      toast.success(`${plan!.code} activated — first payout tomorrow at 00:00 EAT`);
      navigate({ to: "/dashboard" });
    } catch (e: any) {
      toast.error(e?.message || "Could not activate machine");
    } finally {
      setSubmitting(false);
    }
  }


  return (
    <div className="min-h-screen bg-white pb-32">
      {/* Header */}
      <div className="bg-black text-white">
        <div className="mx-auto flex max-w-md items-center gap-3 px-4 py-3">
          <Link
            to="/robots"
            aria-label="Back"
            className="grid h-9 w-9 place-items-center rounded-full bg-white/10"
          >
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <div>
            <p className="text-[0.65rem] uppercase tracking-[0.2em] text-white/70">
              {plan.series} series
            </p>
            <p className="text-lg font-medium leading-tight text-sky-400">{plan.code} · <span className="text-white/90">{plan.name}</span></p>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-md px-4">
        {/* Machine hero */}
        <div className="mt-4 overflow-hidden rounded-2xl border border-sky-300 bg-black">
          <img src={plan.img} alt={plan.code} className="h-56 w-full object-cover" />
        </div>

        {/* Specs */}
        <div className="mt-4 grid grid-cols-2 gap-2.5">
          <Spec icon={Coins} label="Price" value={`UGX ${plan.price.toLocaleString()}`} />
          <Spec icon={Clock} label="Lock" value={plan.lock === 0 ? "No lock" : `${plan.lock} days`} />
          <Spec icon={TrendingUp} label="Daily income" value={`UGX ${Math.round(daily).toLocaleString()}`} tone="primary" />
          <Spec icon={ShieldCheck} label="Total return" value={`UGX ${plan.total.toLocaleString()}`} tone="success" />
        </div>

        <div className="mt-3 rounded-2xl border border-slate-200 bg-slate-50 p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Net profit</span>
            <span className="text-base font-medium text-emerald-600">+UGX {profit.toLocaleString()}</span>
          </div>
          <div className="mt-2 flex items-center justify-between border-t border-slate-200 pt-2">
            <span className="text-xs text-slate-500">Return on investment</span>
            <span className="text-base font-medium text-sky-500">+{roi}%</span>
          </div>
        </div>

        {/* How it works */}
        <div className="mt-4 space-y-2 rounded-2xl bg-slate-50 p-4 text-[0.85rem] text-slate-700">
          <p className="text-sm font-medium text-slate-900">How this machine works</p>
          <div className="flex items-start gap-2">
            <Zap className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sky-500" />
            <p>Earnings are credited to your income balance every day at 00:00 EAT.</p>
          </div>
          <div className="flex items-start gap-2">
            <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sky-500" />
            <p>
              {plan.series === "A"
                ? "No lock period — withdraw earnings any time, no waiting."
                : `Principal (UGX ${plan.price.toLocaleString()}) is released back to your deposit balance after ${plan.lock} days.`}
            </p>
          </div>
        </div>

        {/* Payment source */}
        <div className="mt-5">
          <p className="text-sm font-medium text-slate-900">Pay with</p>
          <p className="mt-0.5 text-xs text-slate-500">
            Choose which balance funds this machine. You can top up your deposit balance from the wallet, or use the earnings you've already collected.
          </p>

          <div className="mt-3 space-y-2">
            <SourceOption
              active={source === "deposit"}
              onClick={() => setSource("deposit")}
              icon={Wallet}
              title="Deposit balance"
              subtitle="Funds you added via MTN MoMo or Airtel Money"
              amount={depositBalance}
            />
            <SourceOption
              active={source === "earnings"}
              onClick={() => setSource("earnings")}
              icon={TrendingUp}
              title="Earnings balance"
              subtitle="Daily income already paid out by your machines"
              amount={earningsBalance}
            />
          </div>
        </div>
      </div>

      {/* Sticky invest bar */}
      <div className="fixed inset-x-0 bottom-16 z-30 border-t border-slate-200 bg-white">
        <div className="mx-auto flex max-w-md items-center gap-3 px-4 py-3">
          <div className="flex-1">
            <p className="text-[0.65rem] uppercase tracking-wider text-slate-500">You pay</p>
            <p className="text-lg font-medium text-slate-900">UGX {plan.price.toLocaleString()}</p>
          </div>
          <button
            onClick={invest}
            disabled={submitting}
            className="flex h-12 flex-1 items-center justify-center gap-2 rounded-full bg-sky-500 text-sm font-medium text-white shadow-[0_6px_20px_-8px_rgba(14,165,233,0.7)] active:scale-[0.98] disabled:opacity-60"
          >
            {submitting ? "Activating..." : `Invest with ${source === "deposit" ? "deposit" : "earnings"}`}
          </button>
        </div>
      </div>
    </div>
  );
}

function Spec({
  icon: Icon,
  label,
  value,
  tone = "default",
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  tone?: "default" | "primary" | "success";
}) {
  const color = tone === "primary" ? "text-sky-500" : tone === "success" ? "text-emerald-600" : "text-slate-900";
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-3">
      <div className="flex items-center gap-1.5 text-[0.6rem] uppercase tracking-wider text-slate-500">
        <Icon className="h-3 w-3" /> {label}
      </div>
      <p className={"mt-1 text-sm font-medium " + color}>{value}</p>
    </div>
  );
}

function SourceOption({
  active,
  onClick,
  icon: Icon,
  title,
  subtitle,
  amount,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  subtitle: string;
  amount: number;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        "flex w-full items-center gap-3 rounded-2xl border p-3 text-left transition-colors " +
        (active ? "border-sky-400 bg-sky-50" : "border-slate-200 bg-white")
      }
    >
      <div
        className={
          "grid h-10 w-10 place-items-center rounded-xl " +
          (active ? "bg-sky-500 text-white" : "bg-slate-100 text-slate-600")
        }
      >
        <Icon className="h-5 w-5" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <p className="text-sm font-medium text-slate-900">{title}</p>
          {active && <Check className="h-3.5 w-3.5 text-sky-500" />}
        </div>
        <p className="truncate text-[0.7rem] text-slate-500">{subtitle}</p>
      </div>
      <p className="shrink-0 text-sm font-medium text-slate-900">
        UGX {amount.toLocaleString()}
      </p>
    </button>
  );
}
