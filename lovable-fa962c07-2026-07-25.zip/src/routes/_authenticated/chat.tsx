import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { Send, Paperclip, Phone, HelpCircle } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { DotWave } from "@/components/DotWave";
import { supabase } from "@/integrations/supabase/client";

const SUPPORT_PHONE = "+256700000000";
const WHATSAPP_URL = "https://wa.me/256700000000";

export const Route = createFileRoute("/_authenticated/chat")({
  head: () => ({ meta: [{ title: "Live Chat — TNX" }] }),
  component: Page,
});

type Msg = {
  id: string;
  from_admin: boolean;
  body: string;
  created_at: string;
};

const QUICK = [
  "How do I deposit?",
  "How long does withdrawal take?",
  "How does the referral bonus work?",
  "Which robot should I start with?",
];

function hm(iso: string) {
  const d = new Date(iso);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

function Page() {
  const [uid, setUid] = useState<string | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async (userId: string) => {
    const { data, error } = await supabase
      .from("support_messages")
      .select("id, from_admin, body, created_at")
      .eq("user_id", userId)
      .order("created_at", { ascending: true });
    if (error) { toast.error(error.message); return; }
    setMessages(data ?? []);
    // mark admin messages read
    await supabase
      .from("support_messages")
      .update({ read_by_user: true })
      .eq("user_id", userId)
      .eq("from_admin", true)
      .eq("read_by_user", false);
  }, []);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      if (!data.user) return;
      setUid(data.user.id);
      await load(data.user.id);
    })();
  }, [load]);

  useEffect(() => {
    if (!uid) return;
    const ch = supabase
      .channel(`support:${uid}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "support_messages", filter: `user_id=eq.${uid}` },
        (payload) => {
          const m = payload.new as Msg;
          setMessages((prev) => (prev.some((x) => x.id === m.id) ? prev : [...prev, m]));
          if (m.from_admin) {
            supabase.from("support_messages").update({ read_by_user: true }).eq("id", m.id).then();
          }
        },
      )
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [uid]);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  async function send(raw?: string) {
    const text = (raw ?? input).trim();
    if (!text || !uid || sending) return;
    setSending(true);
    setInput("");
    const { error } = await supabase.from("support_messages").insert({
      user_id: uid, from_admin: false, sender_id: uid, body: text,
    });
    setSending(false);
    if (error) { toast.error(error.message); setInput(text); }
  }

  function onAttach(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    const size = (f.size / 1024).toFixed(0);
    send(`📎 Attachment: ${f.name} (${size} KB)`);
    e.target.value = "";
  }

  return (
    <div className="relative flex min-h-[calc(100vh-6rem)] flex-col">
      <div className="pointer-events-none fixed inset-0 -z-0 opacity-50"><DotWave /></div>
      <header className="relative z-10 sticky top-0 border-b border-border/60 bg-surface/80 px-4 py-3 backdrop-blur">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="grid h-11 w-11 place-items-center rounded-full bg-gradient-brand text-primary-foreground font-medium">S</div>
            <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-surface bg-success" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium">TNX Support</p>
            <p className="text-[0.7rem] font-normal text-success">● Online · a live agent will reply</p>
          </div>
          <button onClick={() => (window.location.href = `tel:${SUPPORT_PHONE}`)} aria-label="Call" className="grid h-9 w-9 place-items-center rounded-full bg-muted hover:bg-primary hover:text-primary-foreground transition-colors">
            <Phone className="h-4 w-4" />
          </button>
          <button onClick={() => { window.open(WHATSAPP_URL, "_blank", "noopener,noreferrer"); toast.success("Opening WhatsApp"); }} aria-label="WhatsApp" className="grid h-9 w-9 place-items-center rounded-full bg-muted hover:bg-primary hover:text-primary-foreground transition-colors">
            <HelpCircle className="h-4 w-4" />
          </button>
        </div>
      </header>

      <div ref={listRef} className="relative z-10 flex-1 space-y-2.5 overflow-y-auto bg-muted/20 p-4 backdrop-blur-[2px]">
        {messages.length === 0 && (
          <div className="mx-auto mt-6 max-w-sm rounded-2xl bg-surface p-4 text-center text-sm text-muted-foreground shadow-soft">
            Send us a message — an agent will reply here as soon as they're free.
          </div>
        )}
        {messages.map((m) => (
          <Bubble key={m.id} msg={m} />
        ))}
      </div>

      {messages.length <= 1 && (
        <div className="relative z-10 flex gap-2 overflow-x-auto border-t border-border/60 bg-surface/70 px-4 py-2 backdrop-blur [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {QUICK.map((q) => (
            <button key={q} onClick={() => send(q)} className="shrink-0 rounded-full border border-border/70 bg-surface px-3 py-1.5 text-xs hover:border-primary hover:text-primary">
              {q}
            </button>
          ))}
        </div>
      )}

      <form onSubmit={(e) => { e.preventDefault(); send(); }} className="relative z-10 sticky bottom-0 border-t border-border/60 bg-surface/90 p-3 backdrop-blur">
        <div className="flex items-center gap-2">
          <input ref={fileRef} type="file" accept="image/*,application/pdf" onChange={onAttach} className="hidden" />
          <button type="button" onClick={() => fileRef.current?.click()} aria-label="Attach" className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-muted text-muted-foreground hover:text-primary">
            <Paperclip className="h-4 w-4" />
          </button>
          <Input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Type a message..." className="h-11 rounded-xl bg-muted/40" />
          <button type="submit" disabled={!input.trim() || sending} aria-label="Send" className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-brand text-primary-foreground shadow-elegant disabled:opacity-50">
            <Send className="h-4 w-4" />
          </button>
        </div>
      </form>
    </div>
  );
}

function Bubble({ msg }: { msg: Msg }) {
  const mine = !msg.from_admin;
  return (
    <div className={cn("flex", mine ? "justify-end" : "justify-start")}>
      <div className={cn("max-w-[78%] rounded-2xl px-3.5 py-2.5 text-sm shadow-soft",
        mine ? "rounded-tr-sm bg-primary text-primary-foreground" : "rounded-tl-sm bg-surface text-foreground")}>
        <p className="whitespace-pre-wrap break-words leading-snug">{msg.body}</p>
        <p className={cn("mt-1 text-[0.6rem]", mine ? "text-primary-foreground/70" : "text-muted-foreground")}>{hm(msg.created_at)}</p>
      </div>
    </div>
  );
}
