import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ArrowLeft, Send, RefreshCw, MessageSquare } from "lucide-react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/admin/support")({
  head: () => ({ meta: [{ title: "Support Inbox — Admin" }] }),
  component: Page,
});

type Thread = {
  user_id: string;
  full_name: string;
  mobile: string;
  last_body: string;
  last_at: string;
  last_from_admin: boolean;
  unread_admin: number;
};

type Msg = { id: string; from_admin: boolean; body: string; created_at: string };

function hm(iso: string) {
  const d = new Date(iso);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

function Page() {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);
  const [meId, setMeId] = useState<string | null>(null);
  const [threads, setThreads] = useState<Thread[]>([]);
  const [active, setActive] = useState<Thread | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      if (!data.user) { navigate({ to: "/auth" }); return; }
      setMeId(data.user.id);
      const { data: r } = await supabase.rpc("has_role", { _user_id: data.user.id, _role: "admin" });
      if (!r) { toast.error("Admin access required"); navigate({ to: "/dashboard" }); return; }
      setChecking(false);
    })();
  }, [navigate]);

  const loadThreads = useCallback(async () => {
    const { data, error } = await supabase.rpc("admin_list_support_threads");
    if (error) { toast.error(error.message); return; }
    setThreads((data as Thread[]) ?? []);
  }, []);

  useEffect(() => { if (!checking) loadThreads(); }, [checking, loadThreads]);

  const loadMessages = useCallback(async (userId: string) => {
    const { data, error } = await supabase
      .from("support_messages")
      .select("id, from_admin, body, created_at")
      .eq("user_id", userId)
      .order("created_at", { ascending: true });
    if (error) { toast.error(error.message); return; }
    setMessages(data ?? []);
    await supabase
      .from("support_messages")
      .update({ read_by_admin: true })
      .eq("user_id", userId)
      .eq("from_admin", false)
      .eq("read_by_admin", false);
    loadThreads();
  }, [loadThreads]);

  useEffect(() => { if (active) loadMessages(active.user_id); }, [active, loadMessages]);

  // Realtime: subscribe to all support messages while admin has inbox open
  useEffect(() => {
    if (checking) return;
    const ch = supabase
      .channel("admin-support")
      .on("postgres_changes",
        { event: "INSERT", schema: "public", table: "support_messages" },
        (payload) => {
          const m = payload.new as Msg & { user_id: string };
          if (active && m.user_id === active.user_id) {
            setMessages((prev) => (prev.some((x) => x.id === m.id) ? prev : [...prev, m]));
          }
          loadThreads();
        },
      ).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [checking, active, loadThreads]);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  async function reply() {
    const body = text.trim();
    if (!body || !active || !meId || sending) return;
    setSending(true);
    setText("");
    const { error } = await supabase.from("support_messages").insert({
      user_id: active.user_id, from_admin: true, sender_id: meId, body,
    });
    setSending(false);
    if (error) { toast.error(error.message); setText(body); }
  }

  if (checking) return <div className="grid min-h-[60vh] place-items-center text-sm text-muted-foreground">Checking access...</div>;

  return (
    <div className="mx-auto flex min-h-[calc(100vh-6rem)] max-w-6xl gap-3 p-3">
      {/* Thread list */}
      <aside className={cn("w-full md:w-80 shrink-0 rounded-2xl border border-border/60 bg-surface", active && "hidden md:block")}>
        <div className="flex items-center justify-between border-b border-border/60 px-4 py-3">
          <h2 className="text-sm font-medium">Support inbox</h2>
          <button onClick={loadThreads} className="grid h-8 w-8 place-items-center rounded-full hover:bg-muted" aria-label="Refresh"><RefreshCw className="h-4 w-4" /></button>
        </div>
        <div className="max-h-[calc(100vh-10rem)] overflow-y-auto">
          {threads.length === 0 && (
            <div className="p-6 text-center text-xs text-muted-foreground">No conversations yet.</div>
          )}
          {threads.map((t) => (
            <button key={t.user_id} onClick={() => setActive(t)}
              className={cn("flex w-full items-start gap-3 border-b border-border/40 px-4 py-3 text-left hover:bg-muted/40",
                active?.user_id === t.user_id && "bg-muted/60")}>
              <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-gradient-brand text-primary-foreground text-sm font-medium">
                {t.full_name?.[0]?.toUpperCase() ?? "U"}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-sm font-medium">{t.full_name || "Unnamed"}</p>
                  <span className="shrink-0 text-[0.65rem] text-muted-foreground">{hm(t.last_at)}</span>
                </div>
                <p className="truncate text-xs text-muted-foreground">
                  {t.last_from_admin ? "You: " : ""}{t.last_body}
                </p>
                <p className="mt-0.5 truncate text-[0.65rem] text-muted-foreground">{t.mobile}</p>
              </div>
              {t.unread_admin > 0 && (
                <span className="ml-1 grid min-w-[1.25rem] shrink-0 place-items-center rounded-full bg-primary px-1.5 text-[0.65rem] font-medium text-primary-foreground">
                  {t.unread_admin}
                </span>
              )}
            </button>
          ))}
        </div>
      </aside>

      {/* Conversation */}
      <section className={cn("flex flex-1 flex-col rounded-2xl border border-border/60 bg-surface", !active && "hidden md:flex")}>
        {!active ? (
          <div className="grid flex-1 place-items-center text-sm text-muted-foreground">
            <div className="flex flex-col items-center gap-2"><MessageSquare className="h-6 w-6" />Select a conversation</div>
          </div>
        ) : (
          <>
            <header className="flex items-center gap-3 border-b border-border/60 px-4 py-3">
              <button className="md:hidden grid h-9 w-9 place-items-center rounded-full hover:bg-muted" onClick={() => setActive(null)} aria-label="Back"><ArrowLeft className="h-4 w-4" /></button>
              <div className="grid h-10 w-10 place-items-center rounded-full bg-gradient-brand text-primary-foreground text-sm font-medium">
                {active.full_name?.[0]?.toUpperCase() ?? "U"}
              </div>
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{active.full_name || "Unnamed"}</p>
                <p className="truncate text-[0.7rem] text-muted-foreground">{active.mobile}</p>
              </div>
            </header>

            <div ref={listRef} className="flex-1 space-y-2.5 overflow-y-auto bg-muted/20 p-4">
              {messages.map((m) => {
                const admin = m.from_admin;
                return (
                  <div key={m.id} className={cn("flex", admin ? "justify-end" : "justify-start")}>
                    <div className={cn("max-w-[78%] rounded-2xl px-3.5 py-2.5 text-sm shadow-soft",
                      admin ? "rounded-tr-sm bg-primary text-primary-foreground" : "rounded-tl-sm bg-surface")}>
                      <p className="whitespace-pre-wrap break-words leading-snug">{m.body}</p>
                      <p className={cn("mt-1 text-[0.6rem]", admin ? "text-primary-foreground/70" : "text-muted-foreground")}>{hm(m.created_at)}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            <form onSubmit={(e) => { e.preventDefault(); reply(); }} className="border-t border-border/60 p-3">
              <div className="flex items-center gap-2">
                <Input value={text} onChange={(e) => setText(e.target.value)} placeholder={`Reply to ${active.full_name || "user"}...`} className="h-11 rounded-xl bg-muted/40" />
                <button type="submit" disabled={!text.trim() || sending} aria-label="Send" className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-brand text-primary-foreground shadow-elegant disabled:opacity-50">
                  <Send className="h-4 w-4" />
                </button>
              </div>
            </form>
          </>
        )}
      </section>
    </div>
  );
}
