import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Crown, Check, ChevronLeft } from "lucide-react";

export const Route = createFileRoute("/_authenticated/vip")({
  head: () => ({ meta: [{ title: "VIP Tasks — TNX" }] }),
  component: Page,
});

const LEVELS = [
  { tier: "VIP 0", need: 0, perks: ["1 machine slot", "Standard payouts", "Community access"] },
  { tier: "VIP 1", need: 100_000, perks: ["3 machine slots", "+2% daily bonus", "Priority chat"] },
  { tier: "VIP 2", need: 500_000, perks: ["6 machine slots", "+5% daily bonus", "Weekly salary"] },
  { tier: "VIP 3", need: 2_000_000, perks: ["Unlimited slots", "+8% daily bonus", "Personal manager"] },
];

function Page() {
  const [invested, setInvested] = useState(0);
  useEffect(() => {
    supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      const { data: rows } = await supabase
        .from("user_investments").select("price").eq("user_id", data.user.id);
      setInvested((rows ?? []).reduce((s, r) => s + Number(r.price || 0), 0));
    });
  }, []);
  const current = [...LEVELS].reverse().find((l) => invested >= l.need) ?? LEVELS[0];
  return (
    <div className="min-h-screen bg-[#f4f6fa] pb-28">
      <header className="bg-white px-5 py-4 flex items-center gap-3 border-b border-slate-100">
        <Link to="/me" className="p-1"><ChevronLeft className="h-5 w-5" /></Link>
        <h1 className="text-lg text-slate-900">VIP Tasks</h1>
      </header>
      <section className="px-4 pt-4">
        <div className="rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 p-5 text-white shadow">
          <div className="flex items-center gap-2 text-sm opacity-90"><Crown className="h-4 w-4" /> Current tier</div>
          <p className="mt-1 text-3xl">{current.tier}</p>
          <p className="mt-2 text-sm opacity-90">Total invested: UGX {invested.toLocaleString()}</p>
        </div>
      </section>
      <section className="px-4 pt-4 space-y-3">
        {LEVELS.map((l) => {
          const unlocked = invested >= l.need;
          return (
            <div key={l.tier} className={"rounded-2xl bg-white p-4 ring-1 " + (unlocked ? "ring-emerald-200" : "ring-slate-200")}>
              <div className="flex items-center justify-between">
                <p className="text-slate-900">{l.tier}</p>
                <span className={"text-xs " + (unlocked ? "text-emerald-600" : "text-slate-500")}>
                  {unlocked ? "Unlocked" : `Needs UGX ${l.need.toLocaleString()}`}
                </span>
              </div>
              <ul className="mt-2 space-y-1">
                {l.perks.map((p) => (
                  <li key={p} className="flex items-center gap-2 text-sm text-slate-700">
                    <Check className={"h-4 w-4 " + (unlocked ? "text-emerald-500" : "text-slate-400")} /> {p}
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
        <Link to="/robots" className="block text-center rounded-2xl bg-sky-500 py-3.5 text-white">Buy a machine to level up</Link>
      </section>
    </div>
  );
}
