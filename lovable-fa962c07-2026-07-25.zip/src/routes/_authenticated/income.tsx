import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { accrueEarnings } from "@/lib/obpay.functions";
import { DotWave } from "@/components/DotWave";
import { CheckCircle2, XCircle, Clock, Smartphone } from "lucide-react";

export const Route = createFileRoute("/_authenticated/income")({
  head: () => ({ meta: [{ title: "Income — TNX" }] }),
  component: Page,
});

type Section = "Recharge" | "Withdraw" | "Investment" | "AI Income" | "Referral" | "Bonus";
type Status = "success" | "failed" | "pending";

interface Tx {
  id: string;
  section: Section;
  amount: number;
  gross?: number;
  fee?: number;
  created_at: string;
  status: Status;
  reference?: string;
  phone?: string;
  network?: string | null;
  description?: string | null;
  error?: string | null;
}

function Page() {
  const [txs, setTxs] = useState<Tx[]>([]);
  const accrue = useServerFn(accrueEarnings);

  useEffect(() => {
    (async () => {
      try { await (accrue as any)(); } catch { /* ignore */ }
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return;
      const all: Tx[] = [];

      const { data: obtx } = await supabase
        .from("transactions")
        .select("id, type, amount, fee, net_amount, created_at, status, reference, phone, network, description, error_message")
        .eq("user_id", u.user.id)
        .order("created_at", { ascending: false })
        .limit(200);
      if (obtx) {
        for (const t of obtx) {
          const section: Section =
            t.type === "deposit" ? "Recharge"
            : t.type === "withdraw" ? "Withdraw"
            : t.type === "invest" ? "Investment"
            : t.type === "earning" ? "AI Income"
            : "Bonus";

          const displayAmount =
            t.type === "withdraw" && t.net_amount != null ? Number(t.net_amount) : Number(t.amount);
          all.push({
            id: t.id,
            section,
            amount: displayAmount,
            gross: Number(t.amount),
            fee: t.fee != null ? Number(t.fee) : undefined,
            created_at: t.created_at,
            status: (t.status as Status) ?? "pending",
            reference: t.reference,
            phone: t.phone ?? undefined,
            network: t.network,
            description: t.description,
            error: t.error_message,
          });
        }
      }

      const { data: rc } = await supabase
        .from("referral_commissions")
        .select("id, amount, created_at, level")
        .eq("user_id", u.user.id)
        .order("created_at", { ascending: false })
        .limit(50);
      if (rc) {
        for (const r of rc) {
          all.push({
            id: r.id,
            section: "Referral",
            amount: Number(r.amount),
            created_at: r.created_at,
            status: "success",
            description: `Level ${r.level} commission`,
          });
        }
      }
      setTxs(all);
    })();
  }, []);

  const sections: Section[] = ["Recharge", "Withdraw", "Investment", "AI Income", "Referral", "Bonus"];

  return (
    <div className="relative min-h-screen bg-white pb-24">
      <div className="pointer-events-none fixed inset-x-0 bottom-0 top-0 -z-0">
        <DotWave />
      </div>

      <div className="relative z-10 px-4 pt-4 space-y-4">
        {sections.map((s) => {
          const rows = txs.filter((t) => t.section === s);
          const totals = rows.reduce(
            (acc, r) => {
              acc[r.status] = (acc[r.status] || 0) + 1;
              return acc;
            },
            {} as Record<Status, number>,
          );
          return (
            <section key={s}>
              <div className="mb-2 flex items-center justify-between">
                <h2 className="text-sm font-medium text-slate-800">{s}</h2>
                {rows.length > 0 && (
                  <div className="flex gap-1.5 text-[0.65rem]">
                    {totals.success ? <StatusPill status="success" count={totals.success} /> : null}
                    {totals.pending ? <StatusPill status="pending" count={totals.pending} /> : null}
                    {totals.failed ? <StatusPill status="failed" count={totals.failed} /> : null}
                  </div>
                )}
              </div>
              {rows.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-slate-300 bg-white/70 px-4 py-6 text-center text-sm text-slate-500 backdrop-blur">
                  No {s.toLowerCase()} transactions yet.
                </div>
              ) : (
                <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                  {rows.map((r, i) => (
                    <TxRow key={r.id} tx={r} border={i > 0} />
                  ))}
                </div>
              )}
            </section>
          );
        })}
      </div>
    </div>
  );
}

function TxRow({ tx, border }: { tx: Tx; border: boolean }) {
  const negative = tx.section === "Withdraw" || tx.section === "Investment";
  const sign = negative ? "−" : "+";
  const amountColor =
    tx.status === "failed" ? "text-slate-400 line-through"
    : negative ? "text-slate-900"
    : "text-emerald-600";

  return (
    <div className={"px-4 py-3 " + (border ? "border-t border-slate-100" : "")}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <StatusBadge status={tx.status} />
            <p className="truncate text-sm text-slate-900">
              {tx.description || tx.section}
            </p>
          </div>
          <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[0.7rem] text-slate-500">
            <span>{new Date(tx.created_at).toLocaleString()}</span>
            {tx.reference && <span className="font-mono">· {tx.reference}</span>}
          </div>
          {(tx.phone || tx.network) && (
            <div className="mt-1 flex items-center gap-1 text-[0.7rem] text-slate-500">
              <Smartphone className="h-3 w-3" />
              {tx.network ? <span>{tx.network}</span> : null}
              {tx.phone ? <span>· {tx.phone}</span> : null}
            </div>
          )}
          {tx.fee != null && tx.gross != null && (
            <p className="mt-1 text-[0.7rem] text-slate-500">
              Gross UGX {tx.gross.toLocaleString()} · fee UGX {tx.fee.toLocaleString()}
            </p>
          )}
          {tx.status === "failed" && tx.error && (
            <p className="mt-1 text-[0.7rem] text-rose-600">Reason: {tx.error}</p>
          )}
        </div>
        <p className={"shrink-0 text-sm font-medium tabular-nums " + amountColor}>
          {sign}UGX {Number(tx.amount).toLocaleString()}
        </p>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: Status }) {
  if (status === "success")
    return <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[0.6rem] font-medium text-emerald-700 ring-1 ring-emerald-200"><CheckCircle2 className="h-2.5 w-2.5" /> Success</span>;
  if (status === "failed")
    return <span className="inline-flex items-center gap-1 rounded-full bg-rose-50 px-2 py-0.5 text-[0.6rem] font-medium text-rose-700 ring-1 ring-rose-200"><XCircle className="h-2.5 w-2.5" /> Failed</span>;
  return <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-[0.6rem] font-medium text-amber-700 ring-1 ring-amber-200"><Clock className="h-2.5 w-2.5" /> Pending</span>;
}

function StatusPill({ status, count }: { status: Status; count: number }) {
  const cls =
    status === "success" ? "bg-emerald-50 text-emerald-700 ring-emerald-200"
    : status === "failed" ? "bg-rose-50 text-rose-700 ring-rose-200"
    : "bg-amber-50 text-amber-700 ring-amber-200";
  return (
    <span className={"rounded-full px-2 py-0.5 font-medium ring-1 " + cls}>
      {count} {status}
    </span>
  );
}
