import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Users, Gift, ChevronRight, LogOut } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/team")({
  head: () => ({ meta: [{ title: "My Team — TNX" }] }),
  component: Page,
});

interface Profile {
  full_name: string;
  mobile: string;
  referral_code: string;
}

interface LevelRow { level: number; size: number; bonus: number; commission: number }
interface Referral { id: string; full_name: string; mobile: string; created_at: string }

const COMMISSION = { 1: 10, 2: 5, 3: 2 } as const;

function Page() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [levels, setLevels] = useState<LevelRow[]>([
    { level: 1, size: 0, bonus: 0, commission: 10 },
    { level: 2, size: 0, bonus: 0, commission: 5 },
    { level: 3, size: 0, bonus: 0, commission: 2 },
  ]);
  const [directs, setDirects] = useState<Referral[]>([]);
  const [showDetails, setShowDetails] = useState(false);

  useEffect(() => {
    (async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return;
      const uid = u.user.id;

      const { data: p } = await supabase
        .from("profiles")
        .select("full_name, mobile, referral_code")
        .eq("id", uid)
        .maybeSingle();
      if (p) setProfile(p);

      const { data: ov } = await supabase.rpc("get_team_overview", { _user_id: uid });
      if (ov) {
        setLevels(
          [1, 2, 3].map((lv) => {
            const r = ov.find((x: { level: number }) => x.level === lv);
            return {
              level: lv,
              size: Number(r?.size ?? 0),
              bonus: Number(r?.bonus ?? 0),
              commission: COMMISSION[lv as 1 | 2 | 3],
            };
          }),
        );
      }

      const { data: dr } = await supabase.rpc("get_direct_referrals", { _user_id: uid });
      if (dr) setDirects(dr as Referral[]);
    })();
  }, []);

  const totalTeam = levels.reduce((s, l) => s + l.size, 0);
  const totalBonus = levels.reduce((s, l) => s + l.bonus, 0);
  const shareOrigin = (() => {
    if (typeof window === "undefined") return "https://tnxbot.lovable.app";
    const host = window.location.hostname;
    // Preview/sandbox hosts share the production URL instead
    if (host === "localhost" || host.endsWith("lovableproject.com") || host.includes("id-preview--")) {
      return "https://tnxbot.lovable.app";
    }
    return window.location.origin;
  })();
  const inviteLink = profile
    ? `${shareOrigin}/auth?ref=${profile.referral_code}`
    : "";

  async function copy(text: string, label: string) {
    try {
      await navigator.clipboard.writeText(text);
      toast.success(`${label} copied`);
    } catch {
      toast.error("Copy failed");
    }
  }

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="bg-[#f4f6fa] min-h-screen pb-24">
      {/* Header */}
      <div className="rounded-b-3xl bg-black px-5 pt-6 pb-6 text-white">
        <div className="flex items-center justify-between">
          <span className="text-base">Invitation code:</span>
          <div className="flex items-center gap-3">
            <span className="text-2xl tracking-wide">{profile?.referral_code ?? "••••••"}</span>
            <button
              onClick={() => profile && copy(profile.referral_code, "Code")}
              className="rounded-full bg-white/15 px-4 py-1.5 text-sm"
            >
              Copy
            </button>
          </div>
        </div>
        <div className="mt-4 flex items-center justify-between">
          <span className="text-base">Invite link:</span>
          <div className="flex items-center gap-3 min-w-0">
            <span className="truncate text-white/85 max-w-[140px]">{inviteLink}</span>
            <button
              onClick={() => inviteLink && copy(inviteLink, "Link")}
              className="shrink-0 rounded-full bg-white/15 px-4 py-1.5 text-sm"
            >
              Copy Link
            </button>
          </div>
        </div>
      </div>

      {/* My team summary */}
      <section className="px-4 pt-5">
        <h2 className="mb-3 text-xl text-slate-800">My team</h2>
        <div className="grid grid-cols-2 gap-3">
          <div className="flex items-center gap-3 rounded-2xl bg-white p-4 shadow-sm">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-sky-500 text-white">
              <Users className="h-6 w-6" />
            </div>
            <div>
              <p className="text-2xl text-slate-900">{totalTeam}</p>
              <p className="text-xs uppercase tracking-wider text-slate-500">Total<br />Team</p>
            </div>
          </div>
          <div className="flex items-center gap-3 rounded-2xl bg-white p-4 shadow-sm">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-sky-500 text-white">
              <Gift className="h-6 w-6" />
            </div>
            <div>
              <p className="text-2xl text-slate-900">
                {totalBonus.toLocaleString("en-UG", { maximumFractionDigits: 0 })}
              </p>
              <p className="text-xs uppercase tracking-wider text-slate-500">Team<br />Income</p>
            </div>
          </div>
        </div>
      </section>

      {/* Details page */}
      <section className="px-4 pt-6">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="text-xl text-slate-800">Details page</h2>
          <button
            onClick={() => setShowDetails((v) => !v)}
            className="text-sm font-medium text-slate-900 underline underline-offset-4"
          >
            {showDetails ? "Hide details" : "Team Details >"}
          </button>
        </div>

        <div className="space-y-3">
          {levels.map((l) => (
            <div key={l.level} className="overflow-hidden rounded-2xl bg-white shadow-sm">
              <div className="flex items-center justify-between bg-sky-500 px-4 py-2.5 text-white">
                <span className="text-base">Level {l.level}</span>
                <span className="text-sm">Commission: {l.commission}%</span>
              </div>
              <div className="flex items-center justify-between px-4 py-4">
                <div>
                  <p className="text-2xl text-slate-900">{l.size}</p>
                  <p className="text-xs text-slate-500">Team size</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl text-slate-900">
                    {l.bonus.toLocaleString("en-UG", { maximumFractionDigits: 0 })}
                  </p>
                  <p className="text-xs text-slate-500">Bonus (UGX)</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="px-4 pt-6">
        <div className="rounded-2xl bg-white p-4 shadow-sm">
          <h3 className="text-base text-slate-900">How the referral system works</h3>
          <p className="mt-1 text-sm leading-relaxed text-slate-600">
            Share your invitation code or link. When someone joins under you and buys a machine,
            you earn a commission from every deposit and daily payout — three levels deep.
          </p>
          <ul className="mt-3 space-y-2 text-sm text-slate-700">
            <li className="flex items-start gap-2">
              <span className="mt-1 inline-block h-2 w-2 rounded-full bg-sky-500" />
              <span><strong>Level 1 — 10%</strong> from every person you invite directly.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="mt-1 inline-block h-2 w-2 rounded-full bg-sky-400" />
              <span><strong>Level 2 — 5%</strong> from the people your Level 1 team brings in.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="mt-1 inline-block h-2 w-2 rounded-full bg-sky-300" />
              <span><strong>Level 3 — 2%</strong> from anyone your Level 2 team invites.</span>
            </li>
          </ul>
          <p className="mt-3 text-xs text-slate-500">
            Commissions pay to your Earnings balance the moment the referred user's machine runs its
            first cycle. Bonuses shown above update in real time.
          </p>
        </div>
      </section>

      {/* Direct referrals list */}
      {showDetails && (
        <section className="px-4 pt-6">
          <h3 className="mb-2 text-base text-slate-800">People you invited</h3>
          <div className="overflow-hidden rounded-2xl bg-white shadow-sm">
            {directs.length === 0 ? (
              <div className="px-4 py-8 text-center text-sm text-slate-500">
                No referrals yet. Share your link to start earning.
              </div>
            ) : (
              directs.map((r, i) => (
                <div
                  key={r.id}
                  className={
                    "flex items-center gap-3 px-4 py-3 " +
                    (i > 0 ? "border-t border-slate-100" : "")
                  }
                >
                  <div className="grid h-10 w-10 place-items-center rounded-full bg-sky-100 text-sky-600 text-sm">
                    {(r.full_name?.[0] ?? "U").toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm text-slate-900">
                      {r.full_name || "Member"}
                    </p>
                    <p className="text-xs text-slate-500">{r.mobile}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-slate-500">
                      {new Date(r.created_at).toLocaleDateString()}
                    </p>
                    <p className="text-[0.7rem] text-sky-600">Level 1</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-slate-400" />
                </div>
              ))
            )}
          </div>
        </section>
      )}

      <div className="px-4 pt-6">
        <button
          onClick={signOut}
          className="flex w-full items-center justify-center gap-2 rounded-2xl border border-red-200 bg-white py-3.5 text-sm text-red-600 hover:bg-red-50"
        >
          <LogOut className="h-4 w-4" /> Sign out
        </button>
      </div>
    </div>
  );
}
