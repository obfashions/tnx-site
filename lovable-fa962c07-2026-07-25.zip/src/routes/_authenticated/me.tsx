import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Wallet, HandCoins, Receipt, Handshake, Users, Star, Headphones,
  Settings, Download, ChevronsDown, ShieldCheck, Crown, LogOut,
} from "lucide-react";
import brandMark from "@/assets/brand-mark.jpg";
import { MoneySheet } from "@/components/MoneySheet";

export const Route = createFileRoute("/_authenticated/me")({
  head: () => ({ meta: [{ title: "My Account — TNX" }] }),
  component: Page,
});

interface Profile {
  full_name: string;
  mobile: string;
  wallet_balance: number;
  referral_code: string;
}

function Page() {
  const [p, setP] = useState<Profile | null>(null);
  const [earnings, setEarnings] = useState<number>(0);
  const [salary, setSalary] = useState<{ last: number; current: number }>({ last: 0, current: 0 });
  const [frozen, setFrozen] = useState<number>(0);
  const [recharge, setRecharge] = useState<number>(0);
  const [showMore, setShowMore] = useState(false);
  const [money, setMoney] = useState<null | "deposit" | "withdraw">(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      const uid = data.user.id;
      const { data: row } = await supabase
        .from("profiles")
        .select("full_name, mobile, wallet_balance, referral_code")
        .eq("id", uid)
        .maybeSingle();
      if (row) setP(row);
      const { data: r } = await supabase.rpc("has_role", { _user_id: uid, _role: "admin" });
      setIsAdmin(!!r);

      const { data: txs } = await supabase
        .from("transactions")
        .select("type, amount, status, created_at")
        .eq("user_id", uid);
      const rows = (txs ?? []) as unknown as Array<{ type: string; amount: number; status: string; created_at: string }>;
      const earned = rows.filter((t) => t.type === "earning" && t.status === "success")
        .reduce((s, t) => s + Number(t.amount || 0), 0);
      setEarnings(earned);
      const rec = rows.filter((t) => t.type === "deposit" && t.status === "success")
        .reduce((s, t) => s + Number(t.amount || 0), 0);
      setRecharge(rec);
      const pending = rows.filter((t) => t.status === "pending")
        .reduce((s, t) => s + Number(t.amount || 0), 0);
      setFrozen(pending);
      const now = new Date();
      const monthKey = (d: Date) => d.getFullYear() * 12 + d.getMonth();
      const thisM = monthKey(now);
      const lastM = thisM - 1;
      let cur = 0, last = 0;
      rows.filter((t) => t.type === "earning" && t.status === "success").forEach((t) => {
        const k = monthKey(new Date(t.created_at));
        if (k === thisM) cur += Number(t.amount || 0);
        else if (k === lastM) last += Number(t.amount || 0);
      });
      setSalary({ last, current: cur });
    });
  }, []);

  const shortId = p?.mobile?.replace(/^\+?256/, "") || p?.referral_code || "—";
  const name = p?.full_name || "Anon";
  const balance = p?.wallet_balance ?? 0;

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  async function copyRef() {
    if (!p?.referral_code) return;
    try {
      await navigator.clipboard.writeText(p.referral_code);
      toast.success("Referral code copied");
    } catch { toast.error("Copy failed"); }
  }

  type Tile = { label: string; Icon: typeof Wallet; to?: string; onClick?: () => void };
  const tiles: Tile[] = [
    { label: "Deposit", Icon: Wallet, onClick: () => setMoney("deposit") },
    { label: "Withdraw", Icon: HandCoins, onClick: () => setMoney("withdraw") },
    { label: "Bill", Icon: Receipt, to: "/income" },
    { label: "Invite", Icon: Handshake, onClick: copyRef },
    { label: "My team", Icon: Users, to: "/team" },
    { label: "VIP Task", Icon: Star, to: "/vip" },
    { label: "Manager", Icon: Headphones, to: "/chat" },
    { label: "Settings", Icon: Settings, to: "/settings" },
    { label: "Download App", Icon: Download, to: "/download" },
    ...(isAdmin ? [{ label: "Admin", Icon: ShieldCheck, to: "/admin" as const, onClick: undefined }] : []),
  ];


  return (
    <div className="min-h-screen bg-[#f4f6fa] pb-28">
      {/* Header */}
      <header className="bg-white px-5 pt-6 pb-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm text-sky-500">Welcome to TNX</p>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-2xl tracking-wide text-slate-900">{shortId}</span>
              <span className="text-sm text-slate-500">{name}</span>
            </div>
            <div className="mt-2 flex flex-wrap items-center gap-1.5">
              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-1 text-[0.7rem] text-emerald-700 ring-1 ring-emerald-200">
                <ShieldCheck className="h-3 w-3" /> Verified account
              </span>
              <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2.5 py-1 text-[0.7rem] text-amber-700 ring-1 ring-amber-200">
                <Crown className="h-3 w-3" /> VIP 0
              </span>
              <span className="inline-flex items-center gap-1 rounded-full bg-sky-50 px-2.5 py-1 text-[0.7rem] text-sky-700 ring-1 ring-sky-200">
                Ref: {p?.referral_code ?? "······"}
              </span>
            </div>
          </div>
          <div className="grid h-16 w-16 shrink-0 place-items-center rounded-full bg-white ring-2 ring-sky-200 overflow-hidden">
            <img src={brandMark} alt="TNX" className="h-14 w-14 rounded-full object-cover" />
          </div>
        </div>
      </header>

      {/* Wallet / Balance card */}
      <section className="px-4 pt-3">
        <div className="rounded-2xl bg-white p-5 ring-1 ring-sky-200 shadow-sm">
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <p className="text-sm text-slate-500">Wallet</p>
              <p className="mt-1 text-3xl text-slate-900">
                {(p?.wallet_balance ?? 0).toLocaleString("en-UG", { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div>
              <p className="text-sm text-slate-500">Balance</p>
              <p className="mt-1 text-3xl text-slate-900">
                {earnings.toLocaleString("en-UG", { minimumFractionDigits: 2 })}
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowMore((v) => !v)}
            className="mx-auto mt-3 block text-sky-500"
            aria-label="Show more"
          >
            <ChevronsDown className={"h-5 w-5 transition-transform " + (showMore ? "rotate-180" : "")} />
          </button>
          {showMore && (
            <div className="mt-3 grid grid-cols-3 gap-3 border-t border-slate-100 pt-3 text-center">
              <div>
                <p className="text-[0.7rem] uppercase tracking-wider text-slate-500">Recharge</p>
                <p className="text-base text-slate-900">{recharge.toLocaleString("en-UG", { minimumFractionDigits: 2 })}</p>
              </div>
              <div>
                <p className="text-[0.7rem] uppercase tracking-wider text-slate-500">Earnings</p>
                <p className="text-base text-slate-900">{earnings.toLocaleString("en-UG", { minimumFractionDigits: 2 })}</p>
              </div>
              <div>
                <p className="text-[0.7rem] uppercase tracking-wider text-slate-500">Frozen</p>
                <p className="text-base text-slate-900">{frozen.toLocaleString("en-UG", { minimumFractionDigits: 2 })}</p>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Action grid */}
      <section className="px-4 pt-4">
        <div className="rounded-2xl bg-white p-4 ring-1 ring-sky-200 shadow-sm">
          <div className="grid grid-cols-4 gap-y-5 gap-x-2">
            {tiles.map((t) => {
              const inner = (
                <div className="flex flex-col items-center gap-1.5">
                  <div className="grid h-14 w-14 place-items-center rounded-2xl bg-sky-500 text-white shadow-sm">
                    <t.Icon className="h-6 w-6" strokeWidth={2.2} />
                  </div>
                  <span className="text-xs leading-tight text-center text-slate-700">{t.label}</span>
                </div>
              );
              return t.to ? (
                <Link key={t.label} to={t.to as "/team" | "/chat" | "/income" | "/admin" | "/vip" | "/settings" | "/download"} className="block">
                  {inner}
                </Link>
              ) : (
                <button key={t.label} onClick={t.onClick} className="block">
                  {inner}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Salary strip */}
      <section className="px-4 pt-4">
        <div className="rounded-2xl bg-white p-4 ring-1 ring-sky-200 shadow-sm">
          <div className="grid grid-cols-2 gap-3 text-center">
            <div>
              <p className="text-sm text-slate-500">Last month's salary</p>
              <p className="mt-1 text-xl text-slate-900">UGX {salary.last.toLocaleString()}</p>
            </div>
            <div>
              <p className="text-sm text-slate-500">This month's salary</p>
              <p className="mt-1 text-xl text-slate-900">UGX {salary.current.toLocaleString()}</p>
            </div>
          </div>
        </div>
      </section>

      <div className="px-4 pt-4">
        <button
          onClick={signOut}
          className="flex w-full items-center justify-center gap-2 rounded-2xl border border-red-200 bg-white py-3.5 text-sm text-red-600 hover:bg-red-50"
        >
          <LogOut className="h-4 w-4" /> Sign out
        </button>
      </div>

      {money && <MoneySheet kind={money} balance={balance} onClose={() => setMoney(null)} />}
    </div>
  );
}
