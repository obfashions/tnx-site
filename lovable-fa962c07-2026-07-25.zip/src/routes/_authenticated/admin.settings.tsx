import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ArrowLeft, Save, Plus, Trash2, Loader2, RefreshCw } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/settings")({
  head: () => ({ meta: [{ title: "Admin Settings — TNX" }] }),
  component: Page,
});

interface Plan {
  id: string; series: string; code: string; name: string;
  price: number; daily: number; cycle_days: number; lock_days: number;
  total: number; image_url: string | null; sold_out: boolean; active: boolean; sort_order: number;
}

const DEF = {
  welcomeBonus: { enabled: false, amount: 0, message: "" },
  whatsapp: { url: "" },
  popup: { enabled: true, title: "", body: "" },
  withdraw: { min: 5000, max: 2_000_000, fee_percent: 3, fee_min: 500 },
  deposit: { min: 5000, max: 5_000_000 },
};

function Page() {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);

  const [welcomeBonus, setWelcomeBonus] = useState(DEF.welcomeBonus);
  const [whatsapp, setWhatsapp] = useState(DEF.whatsapp);
  const [popup, setPopup] = useState(DEF.popup);
  const [withdraw, setWithdraw] = useState(DEF.withdraw);
  const [deposit, setDeposit] = useState(DEF.deposit);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [newPlan, setNewPlan] = useState({ id: "", name: "", price: 0, daily: 0, cycle_days: 25 });

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      if (!data.user) { navigate({ to: "/auth" }); return; }
      const { data: r } = await supabase.rpc("has_role", { _user_id: data.user.id, _role: "admin" });
      if (!r) { toast.error("Admin access required"); navigate({ to: "/dashboard" }); return; }
      setChecking(false);
    })();
  }, [navigate]);

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: settings, error: sErr }, { data: p, error: pErr }] = await Promise.all([
      supabase.from("app_settings").select("key, value"),
      supabase.from("investment_plans").select("*").order("sort_order", { ascending: true }),
    ]);
    if (sErr) toast.error("Settings: " + sErr.message);
    if (pErr) toast.error("Plans: " + pErr.message);
    for (const s of settings ?? []) {
      const v = s.value as any;
      if (s.key === "welcome_bonus") setWelcomeBonus({ ...DEF.welcomeBonus, ...(v || {}) });
      else if (s.key === "whatsapp_group_url") {
        // seed stored a bare string; admin writes {url:string}
        const url = typeof v === "string" ? v : (v?.url ?? "");
        setWhatsapp({ url });
      }
      else if (s.key === "welcome_popup") setPopup({ ...DEF.popup, ...(v || {}) });
      else if (s.key === "withdraw") setWithdraw({ ...DEF.withdraw, ...(v || {}) });
      else if (s.key === "deposit") setDeposit({ ...DEF.deposit, ...(v || {}) });
    }
    setPlans((p as Plan[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { if (!checking) load(); }, [checking, load]);

  async function saveSetting(key: string, value: unknown) {
    setSaving(key);
    const { error } = await supabase.from("app_settings").upsert({ key, value: value as never }, { onConflict: "key" });
    setSaving(null);
    if (error) toast.error(error.message); else toast.success("Saved " + key);
  }

  async function savePlan(p: Plan) {
    setSaving(p.id);
    const { error } = await supabase.from("investment_plans").update({
      series: p.series, code: p.code, name: p.name,
      price: Number(p.price), daily: Number(p.daily), cycle_days: Number(p.cycle_days),
      lock_days: Number(p.lock_days), total: Number(p.total),
      image_url: p.image_url, sold_out: p.sold_out, active: p.active, sort_order: Number(p.sort_order),
    }).eq("id", p.id);
    setSaving(null);
    if (error) toast.error(error.message); else toast.success(`${p.code} saved`);
  }

  async function deletePlan(p: Plan) {
    if (!window.confirm(`Delete plan ${p.code}?`)) return;
    const { error } = await supabase.from("investment_plans").delete().eq("id", p.id);
    if (error) toast.error(error.message);
    else { toast.success("Deleted"); load(); }
  }

  async function addPlan() {
    const id = newPlan.id.trim().toLowerCase();
    if (!id) { toast.error("Enter an id like w-7"); return; }
    if (plans.some((p) => p.id === id)) { toast.error("That id already exists"); return; }
    const series = id.split("-")[0]?.toUpperCase() || "W";
    const total = Number(newPlan.daily) * Number(newPlan.cycle_days);
    const { error } = await supabase.from("investment_plans").insert({
      id, series, code: id.toUpperCase(), name: newPlan.name || "New machine",
      price: Number(newPlan.price), daily: Number(newPlan.daily),
      cycle_days: Number(newPlan.cycle_days), lock_days: Number(newPlan.cycle_days),
      total, image_url: null, sold_out: false, active: true, sort_order: plans.length + 1,
    });
    if (error) { toast.error(error.message); return; }
    toast.success("Plan added");
    setNewPlan({ id: "", name: "", price: 0, daily: 0, cycle_days: 25 });
    load();
  }

  if (checking) return <div className="grid min-h-screen place-items-center bg-black text-white/70">Checking access…</div>;

  return (
    <div className="min-h-screen bg-[#0b0f16] pb-28 text-white">
      <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-white/10 bg-black/95 px-4 py-3 backdrop-blur">
        <Link to="/admin" className="grid h-9 w-9 place-items-center rounded-full bg-white/10"><ArrowLeft className="h-4 w-4" /></Link>
        <div className="flex-1">
          <h1 className="text-base">App Settings</h1>
          <p className="text-[0.7rem] text-white/50">Bonus · Limits · Plans · Links</p>
        </div>
        <button onClick={load} className="grid h-9 w-9 place-items-center rounded-full bg-white/10"><RefreshCw className={"h-4 w-4 " + (loading ? "animate-spin" : "")} /></button>
      </header>

      {loading ? (
        <div className="grid place-items-center py-20"><Loader2 className="h-6 w-6 animate-spin text-sky-400" /></div>
      ) : (
        <div className="space-y-4 px-4 pt-4">
          <Card title="Welcome bonus">
            <Row>
              <Toggle label="Enabled" checked={welcomeBonus.enabled} onChange={(v) => setWelcomeBonus({ ...welcomeBonus, enabled: v })} />
              <NumField label="Amount (UGX)" value={welcomeBonus.amount} onChange={(v) => setWelcomeBonus({ ...welcomeBonus, amount: v })} />
            </Row>
            <SaveBtn busy={saving === "welcome_bonus"} onClick={() => saveSetting("welcome_bonus", welcomeBonus)} />
          </Card>

          <Card title="WhatsApp group link">
            <TextField label="URL" value={whatsapp.url} onChange={(v) => setWhatsapp({ url: v })} placeholder="https://chat.whatsapp.com/..." />
            <SaveBtn busy={saving === "whatsapp_group_url"} onClick={() => saveSetting("whatsapp_group_url", whatsapp)} />
          </Card>

          <Card title="Welcome popup">
            <Toggle label="Show popup after login" checked={popup.enabled} onChange={(v) => setPopup({ ...popup, enabled: v })} />
            <TextField label="Title" value={popup.title} onChange={(v) => setPopup({ ...popup, title: v })} />
            <TextArea label="Body" value={popup.body} onChange={(v) => setPopup({ ...popup, body: v })} />
            <SaveBtn busy={saving === "welcome_popup"} onClick={() => saveSetting("welcome_popup", popup)} />
          </Card>

          <Card title="Withdrawal limits & fee">
            <Row>
              <NumField label="Min UGX" value={withdraw.min} onChange={(v) => setWithdraw({ ...withdraw, min: v })} />
              <NumField label="Max UGX" value={withdraw.max} onChange={(v) => setWithdraw({ ...withdraw, max: v })} />
            </Row>
            <Row>
              <NumField label="Fee %" value={withdraw.fee_percent} onChange={(v) => setWithdraw({ ...withdraw, fee_percent: v })} />
              <NumField label="Min fee UGX" value={withdraw.fee_min} onChange={(v) => setWithdraw({ ...withdraw, fee_min: v })} />
            </Row>
            <SaveBtn busy={saving === "withdraw"} onClick={() => saveSetting("withdraw", withdraw)} />
          </Card>

          <Card title="Deposit / recharge limits">
            <Row>
              <NumField label="Min UGX" value={deposit.min} onChange={(v) => setDeposit({ ...deposit, min: v })} />
              <NumField label="Max UGX" value={deposit.max} onChange={(v) => setDeposit({ ...deposit, max: v })} />
            </Row>
            <SaveBtn busy={saving === "deposit"} onClick={() => saveSetting("deposit", deposit)} />
          </Card>

          <Card title={`Add investment plan`}>
            <Row>
              <TextField label="ID (e.g. w-7)" value={newPlan.id} onChange={(v) => setNewPlan({ ...newPlan, id: v })} />
              <TextField label="Name" value={newPlan.name} onChange={(v) => setNewPlan({ ...newPlan, name: v })} />
            </Row>
            <Row>
              <NumField label="Price UGX" value={newPlan.price} onChange={(v) => setNewPlan({ ...newPlan, price: v })} />
              <NumField label="Daily UGX" value={newPlan.daily} onChange={(v) => setNewPlan({ ...newPlan, daily: v })} />
            </Row>
            <NumField label="Cycle days" value={newPlan.cycle_days} onChange={(v) => setNewPlan({ ...newPlan, cycle_days: v })} />
            <button onClick={addPlan} className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-lg bg-emerald-500 py-2 text-xs font-medium"><Plus className="h-3.5 w-3.5" /> Add plan</button>
          </Card>

          <Card title={`Investment plans (${plans.length})`}>
            <div className="space-y-3">
              {plans.map((p, i) => (
                <div key={p.id} className="rounded-xl bg-white/5 p-3 ring-1 ring-white/10">
                  <div className="mb-2 flex items-center justify-between">
                    <span className="text-sm text-sky-300">{p.id}</span>
                    <div className="flex gap-3">
                      <Toggle label="Active" checked={p.active} onChange={(v) => setPlans(plans.map((x, j) => j === i ? { ...x, active: v } : x))} />
                      <Toggle label="Sold" checked={p.sold_out} onChange={(v) => setPlans(plans.map((x, j) => j === i ? { ...x, sold_out: v } : x))} />
                    </div>
                  </div>
                  <Row>
                    <TextField label="Code" value={p.code} onChange={(v) => setPlans(plans.map((x, j) => j === i ? { ...x, code: v } : x))} />
                    <TextField label="Series" value={p.series} onChange={(v) => setPlans(plans.map((x, j) => j === i ? { ...x, series: v } : x))} />
                  </Row>
                  <TextField label="Name" value={p.name} onChange={(v) => setPlans(plans.map((x, j) => j === i ? { ...x, name: v } : x))} />
                  <Row>
                    <NumField label="Price" value={p.price} onChange={(v) => setPlans(plans.map((x, j) => j === i ? { ...x, price: v } : x))} />
                    <NumField label="Daily" value={p.daily} onChange={(v) => setPlans(plans.map((x, j) => j === i ? { ...x, daily: v } : x))} />
                  </Row>
                  <Row>
                    <NumField label="Cycle days" value={p.cycle_days} onChange={(v) => setPlans(plans.map((x, j) => j === i ? { ...x, cycle_days: v } : x))} />
                    <NumField label="Lock days" value={p.lock_days} onChange={(v) => setPlans(plans.map((x, j) => j === i ? { ...x, lock_days: v } : x))} />
                  </Row>
                  <Row>
                    <NumField label="Total" value={p.total} onChange={(v) => setPlans(plans.map((x, j) => j === i ? { ...x, total: v } : x))} />
                    <NumField label="Order" value={p.sort_order} onChange={(v) => setPlans(plans.map((x, j) => j === i ? { ...x, sort_order: v } : x))} />
                  </Row>
                  <TextField label="Image URL" value={p.image_url ?? ""} onChange={(v) => setPlans(plans.map((x, j) => j === i ? { ...x, image_url: v || null } : x))} />
                  <div className="mt-2 flex gap-2">
                    <button disabled={saving === p.id} onClick={() => savePlan(p)} className="flex flex-1 items-center justify-center gap-1 rounded-lg bg-sky-500 py-2 text-xs disabled:opacity-60">
                      {saving === p.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />} Save
                    </button>
                    <button onClick={() => deletePlan(p)} className="flex items-center justify-center gap-1 rounded-lg bg-rose-500/20 px-3 py-2 text-xs text-rose-300 ring-1 ring-rose-500/30"><Trash2 className="h-3.5 w-3.5" /></button>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}

function Card({ title, action, children }: { title: string; action?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-sm">{title}</h2>
        {action}
      </div>
      <div className="space-y-2">{children}</div>
    </div>
  );
}
function Row({ children }: { children: React.ReactNode }) { return <div className="grid grid-cols-2 gap-2">{children}</div>; }
function TextField({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[0.65rem] uppercase tracking-wider text-white/50">{label}</span>
      <input value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} className="w-full rounded-lg bg-white/5 px-3 py-2 text-sm outline-none ring-1 ring-white/10 focus:ring-sky-500" />
    </label>
  );
}
function TextArea({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[0.65rem] uppercase tracking-wider text-white/50">{label}</span>
      <textarea value={value} onChange={(e) => onChange(e.target.value)} rows={5} className="w-full rounded-lg bg-white/5 px-3 py-2 text-sm outline-none ring-1 ring-white/10 focus:ring-sky-500" />
    </label>
  );
}
function NumField({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[0.65rem] uppercase tracking-wider text-white/50">{label}</span>
      <input type="number" value={value} onChange={(e) => onChange(Number(e.target.value) || 0)} className="w-full rounded-lg bg-white/5 px-3 py-2 text-sm outline-none ring-1 ring-white/10 focus:ring-sky-500" />
    </label>
  );
}
function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button type="button" onClick={() => onChange(!checked)} className="flex items-center gap-2 text-xs">
      <span className={"grid h-5 w-9 items-center rounded-full transition-colors " + (checked ? "bg-sky-500" : "bg-white/15")}>
        <span className={"h-4 w-4 rounded-full bg-white transition-transform " + (checked ? "translate-x-4" : "translate-x-0.5")} />
      </span>
      <span className="text-white/80">{label}</span>
    </button>
  );
}
function SaveBtn({ onClick, busy }: { onClick: () => void; busy?: boolean }) {
  return (
    <button disabled={busy} onClick={onClick} className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-lg bg-sky-500 py-2 text-xs disabled:opacity-60">
      {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />} Save
    </button>
  );
}
