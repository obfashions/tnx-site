import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { Bell, MessageSquare, Play, Cpu, Clock } from "lucide-react";
import { MoneySheet } from "@/components/MoneySheet";
import { WelcomePopup } from "@/components/WelcomePopup";
import { accrueEarnings } from "@/lib/obpay.functions";
import bannerRobot from "@/assets/banner-robot-live.jpg";
import bannerHappy from "@/assets/banner-happy-team.jpg";
import bannerManagers from "@/assets/banner-managers.jpg";
import bannerWelding from "@/assets/banner-arms-welding.jpg";
import bannerAssembly from "@/assets/banner-arms-assembly.jpg";
import bannerPacking from "@/assets/banner-arms-packing.jpg";
import { fetchPlans, type Plan } from "./robots.index";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — TNX" }] }),
  component: Dashboard,
});

interface Profile { full_name: string; wallet_balance: number; referral_code: string; }
interface RunningPlan {
  id: string; plan_name: string; price: number; daily: number;
  cycle_days: number; days_paid: number; total_earned: number;
  status: string; started_at: string; ends_at: string;
}

const FEATURED_IDS = ["w-2", "k-2", "a-3", "w-4", "k-4"];

function Dashboard() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [money, setMoney] = useState<null | "deposit" | "withdraw">(null);
  const [hot, setHot] = useState<Plan[]>([]);
  const [running, setRunning] = useState<RunningPlan[]>([]);
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const [todayEarn, setTodayEarn] = useState(0);
  const [totalEarn, setTotalEarn] = useState(0);
  const accrue = useServerFn(accrueEarnings);

  async function loadProfile() {
    const { data } = await supabase.auth.getUser();
    if (!data.user) return;
    const uid = data.user.id;
    const { data: p } = await supabase
      .from("profiles").select("full_name, wallet_balance, referral_code")
      .eq("id", uid).maybeSingle();
    if (p) setProfile(p);

    const { data: inv } = await supabase
      .from("user_investments")
      .select("id, plan_name, price, daily, cycle_days, days_paid, total_earned, status, started_at, ends_at")
      .eq("user_id", uid)
      .order("created_at", { ascending: false });
    setRunning((inv || []) as RunningPlan[]);

    const startOfDay = new Date(); startOfDay.setHours(0, 0, 0, 0);
    const { data: earn } = await supabase
      .from("transactions").select("amount, created_at")
      .eq("user_id", uid).eq("type", "earning").eq("status", "success");
    let today = 0, total = 0;
    for (const r of earn || []) {
      const a = Number(r.amount);
      total += a;
      if (new Date(r.created_at) >= startOfDay) today += a;
    }
    setTodayEarn(today); setTotalEarn(total);
  }

  useEffect(() => {
    (async () => {
      try { await (accrue as any)(); } catch { /* ignore */ }
      await loadProfile();
      const plans = await fetchPlans();
      const featured = FEATURED_IDS.map((id) => plans.find((x) => x.id === id)).filter(Boolean) as Plan[];
      setHot(featured.length ? featured : plans.slice(0, 5));
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);



  const balance = profile?.wallet_balance ?? 0;


  return (
    <div className="min-h-screen bg-white text-slate-900">
      <WelcomePopup />
      {/* Top black bar */}
      <header className="flex items-center justify-between bg-black px-4 py-3 text-white">
        <h1 className="font-display text-2xl font-semibold tracking-tight">TNX</h1>
        <Link to="/chat" className="relative flex flex-col items-center">
          <Bell className="h-5 w-5" />
          <span className="absolute -right-2 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-red-500 px-1 text-[0.6rem] font-medium">0</span>
          <span className="mt-0.5 text-[0.65rem] font-normal">Message</span>
        </Link>
      </header>

      {/* Banner */}
      <section className="px-0">
        <div className="relative h-44 w-full overflow-hidden">
          <img src={bannerRobot} alt="TNX factory floor" className="h-full w-full object-cover" />
        </div>
        <div className="bg-slate-800 px-4 py-3 text-white">
          <p className="text-[0.95rem] font-normal leading-snug text-sky-300">
            Vraies machines. Vrais paiements. Fabriqués ici même en Ouganda.
          </p>
        </div>
      </section>

      {/* Scenes from the floor — auto-scrolling banners */}
      <section className="mt-3">
        <div className="flex items-baseline justify-between px-4 pb-2">
          <h2 className="font-display text-[15px] font-medium tracking-tight text-white">Scènes de l'atelier</h2>
          <span className="text-[11px] uppercase tracking-widest text-white/50">En direct</span>
        </div>
        <div className="group relative overflow-hidden">
          <div className="flex w-max animate-[floor-scroll_40s_linear_infinite] gap-3 px-4 group-hover:[animation-play-state:paused]">
            {[
              { src: bannerWelding, title: "Bras soudeurs KUKA", sub: "Ligne d'assemblage automobile — Ouganda" },
              { src: bannerAssembly, title: "Cellule d'assemblage", sub: "Placement de précision, 24 h/24" },
              { src: bannerPacking, title: "Palettisation robotisée", sub: "Entrepôt logistique — Kampala" },
              { src: bannerHappy, title: "Équipe en poste", sub: "Opérateurs et machines, main dans la main" },
              { src: bannerManagers, title: "Superviseurs sur le terrain", sub: "Contrôle qualité en temps réel" },
              // duplicate for seamless loop
              { src: bannerWelding, title: "Bras soudeurs KUKA", sub: "Ligne d'assemblage automobile — Ouganda" },
              { src: bannerAssembly, title: "Cellule d'assemblage", sub: "Placement de précision, 24 h/24" },
              { src: bannerPacking, title: "Palettisation robotisée", sub: "Entrepôt logistique — Kampala" },
              { src: bannerHappy, title: "Équipe en poste", sub: "Opérateurs et machines, main dans la main" },
              { src: bannerManagers, title: "Superviseurs sur le terrain", sub: "Contrôle qualité en temps réel" },
            ].map((s, i) => (
              <figure key={i} className="relative h-40 w-72 shrink-0 overflow-hidden rounded-xl ring-1 ring-white/10">
                <img src={s.src} alt={s.title} loading="lazy" className="h-full w-full object-cover" />
                <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent px-3 pb-2 pt-6 text-white">
                  <p className="text-[13px] font-medium leading-tight">{s.title}</p>
                  <p className="mt-0.5 text-[11px] font-normal text-white/70">{s.sub}</p>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* 2x2 stat cards */}
      <section className="grid grid-cols-2 gap-3 px-3 pt-4">
        <StatCard value={fmt(balance)} label="Deposit details" onClick={() => setMoney("deposit")} />
        <StatCard value={fmt(totalEarn)} label="Withdraw details" onClick={() => setMoney("withdraw")} />
        <StatCard value={fmt(totalEarn)} label="AI Income" />
        <StatCard value={fmt(todayEarn)} label="Today's earnings" />
      </section>

      {/* 3-cell row */}
      <section className="grid grid-cols-3 gap-3 px-3 pt-3">

        <StatCard value="0" label="Invite Count" small />
        <StatCard value="0" label="Team Count" small />
        <StatCard value="0.00" label="Team income" small />
      </section>

      {/* Deposit / Withdraw */}
      <section className="grid grid-cols-2 gap-3 px-3 pt-4">
        <button
          onClick={() => setMoney("deposit")}
          className="h-12 rounded-md bg-sky-600 text-sm font-medium text-white shadow-sm active:scale-[0.98] transition-transform"
        >
          Deposit
        </button>
        <button
          onClick={() => setMoney("withdraw")}
          className="h-12 rounded-md bg-slate-800 text-sm font-medium text-white shadow-sm active:scale-[0.98] transition-transform"
        >
          Withdraw
        </button>
      </section>

      {/* My running machines */}
      <section className="px-3 pt-5">
        <div className="flex items-center gap-2">
          <Cpu className="h-4 w-4 text-sky-600" />
          <h2 className="text-[0.78rem] font-medium uppercase tracking-[0.18em] text-slate-900">My Machines</h2>
          <Link to="/robots" className="ml-auto text-[0.72rem] font-normal text-sky-600">Buy more →</Link>
        </div>
        {running.length === 0 ? (
          <div className="mt-3 rounded-xl border border-dashed border-slate-300 bg-slate-50 p-4 text-center">
            <p className="text-[0.85rem] text-slate-600">No machines running yet. Activate one and earnings top up your wallet every 24 hours.</p>
            <Link to="/robots" className="mt-2 inline-block text-[0.8rem] font-medium text-sky-600">Browse machines →</Link>
          </div>
        ) : (
          <div className="mt-3 space-y-2">
            {running.map((r) => {
              const pct = Math.min(100, Math.round((r.days_paid / r.cycle_days) * 100));
              const daysLeft = Math.max(0, r.cycle_days - r.days_paid);
              const done = r.status === "completed" || daysLeft === 0;
              const nextPayoutMs = new Date(r.started_at).getTime() + (r.days_paid + 1) * 86400_000 - now;
              const hrs = Math.max(0, Math.floor(nextPayoutMs / 3_600_000));
              const mins = Math.max(0, Math.floor((nextPayoutMs % 3_600_000) / 60_000));
              const secs = Math.max(0, Math.floor((nextPayoutMs % 60_000) / 1000));
              return (
                <div key={r.id} className={"rounded-xl border p-3 " + (done ? "border-slate-200 bg-slate-50" : "border-sky-300 bg-white")}>
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-slate-900">{r.plan_name}</p>
                    <span className={"rounded-full px-2 py-0.5 text-[0.6rem] font-medium uppercase " + (done ? "bg-slate-200 text-slate-600" : "bg-emerald-100 text-emerald-700")}>
                      {done ? "Completed" : "Running"}
                    </span>
                  </div>
                  <div className="mt-1 flex items-center justify-between text-[0.72rem] text-slate-600">
                    <span>Daily UGX {Number(r.daily).toLocaleString()}</span>
                    <span>Earned UGX {Number(r.total_earned).toLocaleString()}</span>
                  </div>
                  <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-200">
                    <div className="h-full rounded-full bg-sky-500" style={{ width: pct + "%" }} />
                  </div>
                  <div className="mt-1.5 flex items-center justify-between text-[0.68rem] text-slate-500">
                    <span>Day {r.days_paid} / {r.cycle_days}</span>
                    {done ? (
                      <span className="text-emerald-600">Cycle complete</span>
                    ) : (
                      <span className="flex items-center gap-1 tabular-nums"><Clock className="h-3 w-3" /> Next payout in {String(hrs).padStart(2,"0")}:{String(mins).padStart(2,"0")}:{String(secs).padStart(2,"0")}</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>


      <section className="px-3 pt-4">
        <div className="overflow-hidden rounded-md bg-slate-900 text-white shadow-sm">
          <div className="flex items-center justify-between px-4 py-3">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-sky-400" />
              <span className="font-display text-base font-semibold">Announcements</span>
            </div>
            <Link to="/chat" className="text-[0.8rem] font-normal text-sky-400">More</Link>
          </div>
          <ul className="divide-y divide-white/10 bg-white text-slate-800">
            {[
              { t: "MTN and Airtel payouts are moving fast today — no queue.", d: "Today · 08:12", tag: "Payouts", unread: true },
              { t: "N-2P has only 6 slots left this week. Grab yours before Friday.", d: "Today · 06:40", tag: "Machines" },
              { t: "New F-series arms just landed in Jinja. Line B now hiring 2 investors.", d: "Yesterday · 17:22", tag: "Factory" },
              { t: "Team meet-up Saturday, 3pm at Kampala Bay 3. Snacks on the house.", d: "Sun · 12:00", tag: "Community" },
            ].map((n, i) => (
              <li key={i} className="flex items-start gap-3 px-4 py-3">
                <div className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-md bg-sky-100 text-sky-700">
                  <MessageSquare className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-[0.82rem] leading-snug font-normal">{n.t}</p>
                  <div className="mt-1 flex items-center gap-2">
                    <span className="rounded-sm bg-slate-100 px-1.5 py-0.5 text-[0.6rem] font-medium uppercase tracking-wide text-slate-600">{n.tag}</span>
                    <span className="text-[0.65rem] font-normal text-slate-400">{n.d}</span>
                  </div>
                </div>
                {n.unread && <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-red-500" />}
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Working Right Now — same card style as the AI page */}
      <section className="px-3 pb-28 pt-5">
        <div className="flex items-center gap-2">
          <Play className="h-3.5 w-3.5 fill-slate-900 text-slate-900" />
          <h2 className="text-[0.78rem] font-medium uppercase tracking-[0.18em] text-slate-900">Working Right Now</h2>
          <Link to="/robots" className="ml-auto text-[0.72rem] font-normal text-sky-600">See all →</Link>
        </div>
        <div className="mt-3 space-y-4">
          {hot.map((p) => (
            <Link key={p.id} to="/robots/$id" params={{ id: p.id }} className="block active:opacity-90">
              <div className="flex items-stretch gap-3 rounded-xl border border-sky-300 bg-white p-2 shadow-[0_1px_0_rgba(0,0,0,0.02)]">
                <div className="relative h-[112px] w-[132px] shrink-0 overflow-hidden rounded-lg bg-black">
                  <img src={p.img} alt={p.code} className="h-full w-full object-cover" loading="lazy" />
                </div>
                <div className="min-w-0 flex-1 py-1">
                  <div className="flex items-baseline gap-2">
                    <p className="text-lg font-medium text-sky-500">{p.code}</p>
                    <p className="truncate text-[0.72rem] font-normal text-slate-500">{p.name}</p>
                  </div>
                  <p className="mt-0.5 text-[0.85rem] text-slate-800">
                    Lock: {p.lock === 0 ? "No lock" : `${p.lock} Days`} · Runs {p.days}d
                  </p>
                  <p className="text-[0.85rem] text-slate-800">Price: UGX {p.price.toLocaleString()}</p>
                  <p className="text-[0.85rem] text-slate-800">
                    Daily: <span className="font-medium text-emerald-600">UGX {p.daily.toLocaleString()}</span>
                  </p>
                  <p className="text-[0.85rem] text-slate-800">
                    Total: <span className="font-medium text-emerald-600">UGX {p.total.toLocaleString()}</span>
                  </p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {money && <MoneySheet kind={money} balance={balance} onClose={() => setMoney(null)} onSuccess={loadProfile} />}
    </div>
  );
}

function fmt(n: number) {
  return n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function StatCard({ value, label, small, onClick }: { value: string; label: string; small?: boolean; onClick?: () => void }) {
  const Comp: any = onClick ? "button" : "div";
  return (
    <Comp onClick={onClick} className="overflow-hidden rounded-md bg-white text-center shadow-sm ring-1 ring-slate-200">
      <div className={"grid place-items-center bg-white " + (small ? "h-14" : "h-16")}>
        <span className="text-lg font-normal text-slate-800">{value}</span>
      </div>
      <div className="bg-slate-700 py-2 text-white">
        <span className={"font-normal " + (small ? "text-[0.72rem]" : "text-[0.8rem]")}>{label}</span>
      </div>
    </Comp>
  );
}
