import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Search, Shield, ShieldOff, Save, Trash2, RefreshCw, LogOut, X, Settings, MessageSquare } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/")({
  head: () => ({ meta: [{ title: "Admin Panel — TNX" }] }),
  component: Page,
});

interface AdminUser {
  id: string;
  full_name: string;
  mobile: string;
  email: string | null;
  wallet_balance: number;
  referral_code: string;
  referred_by: string | null;
  is_admin: boolean;
  created_at: string;
}

function Page() {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);
  const [allowed, setAllowed] = useState(false);
  const [meId, setMeId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(false);
  const [editing, setEditing] = useState<AdminUser | null>(null);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      if (!data.user) { navigate({ to: "/auth" }); return; }
      setMeId(data.user.id);
      const { data: r } = await supabase.rpc("has_role", { _user_id: data.user.id, _role: "admin" });
      if (!r) {
        toast.error("Admin access required");
        navigate({ to: "/dashboard" });
        return;
      }
      setAllowed(true);
      setChecking(false);
    })();
  }, [navigate]);

  const load = useCallback(async (q = "") => {
    setLoading(true);
    const { data, error } = await supabase.rpc("admin_list_users", { _search: q || undefined });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    setUsers((data as AdminUser[]) ?? []);
  }, []);

  useEffect(() => { if (allowed) load(); }, [allowed, load]);

  async function logAction(target: string, action: string, details: Record<string, unknown>) {
    if (!meId) return;
    await supabase.from("admin_actions").insert({ admin_id: meId, target_user_id: target, action, details: details as never });
  }

  async function saveEdit(u: AdminUser, patch: Partial<AdminUser>) {
    const { error } = await supabase.from("profiles").update({
      full_name: patch.full_name ?? u.full_name,
      mobile: patch.mobile ?? u.mobile,
      wallet_balance: patch.wallet_balance ?? u.wallet_balance,
      referral_code: patch.referral_code ?? u.referral_code,
      referred_by: patch.referred_by ?? u.referred_by,
    }).eq("id", u.id);
    if (error) return toast.error(error.message);
    await logAction(u.id, "update_profile", patch as Record<string, unknown>);
    toast.success("Saved");
    setEditing(null);
    load(search);
  }

  async function toggleAdmin(u: AdminUser) {
    if (u.is_admin) {
      const { error } = await supabase.from("user_roles").delete().eq("user_id", u.id).eq("role", "admin");
      if (error) return toast.error(error.message);
      await logAction(u.id, "revoke_admin", {});
      toast.success("Admin revoked");
    } else {
      const { error } = await supabase.from("user_roles").insert({ user_id: u.id, role: "admin" });
      if (error) return toast.error(error.message);
      await logAction(u.id, "grant_admin", {});
      toast.success("Admin granted");
    }
    load(search);
  }

  async function deleteProfile(u: AdminUser) {
    if (u.id === meId) return toast.error("You cannot delete your own account here");
    if (!confirm(`Delete profile for ${u.full_name || u.mobile}? This removes their profile row.`)) return;
    const { error } = await supabase.from("profiles").delete().eq("id", u.id);
    if (error) return toast.error(error.message);
    await logAction(u.id, "delete_profile", { mobile: u.mobile });
    toast.success("Deleted");
    load(search);
  }

  async function adjustBalance(u: AdminUser, delta: number) {
    const next = Number(u.wallet_balance) + delta;
    const { error } = await supabase.from("profiles").update({ wallet_balance: next }).eq("id", u.id);
    if (error) return toast.error(error.message);
    await logAction(u.id, "adjust_balance", { delta, from: u.wallet_balance, to: next });
    toast.success(`Balance ${delta >= 0 ? "+" : ""}${delta}`);
    load(search);
  }

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  if (checking) {
    return <div className="grid min-h-screen place-items-center bg-black text-white/70">Checking access…</div>;
  }

  return (
    <div className="min-h-screen bg-[#0b0f16] pb-28 text-white">
      <header className="sticky top-0 z-20 bg-black/95 backdrop-blur border-b border-white/10 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-sky-400" />
          <div>
            <h1 className="text-base">Admin Console</h1>
            <p className="text-[0.7rem] text-white/50">Full control · TNX</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Link to="/admin/support" className="rounded-full border border-white/15 px-3 py-1.5 text-xs flex items-center gap-1.5">
            <MessageSquare className="h-3.5 w-3.5" /> Support
          </Link>
          <Link to="/admin/settings" className="rounded-full border border-white/15 px-3 py-1.5 text-xs flex items-center gap-1.5">
            <Settings className="h-3.5 w-3.5" /> Settings
          </Link>
          <button onClick={signOut} className="rounded-full border border-white/15 px-3 py-1.5 text-xs flex items-center gap-1.5">
            <LogOut className="h-3.5 w-3.5" /> Sign out
          </button>
        </div>
      </header>

      <div className="px-4 pt-4">
        <div className="flex gap-2">
          <div className="flex flex-1 items-center gap-2 rounded-xl bg-white/5 border border-white/10 px-3 py-2.5">
            <Search className="h-4 w-4 text-white/50" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && load(search)}
              placeholder="Search name, mobile, email, code…"
              className="flex-1 bg-transparent text-sm outline-none placeholder:text-white/40"
            />
          </div>
          <button onClick={() => load(search)} className="rounded-xl bg-sky-500 px-4 text-sm flex items-center gap-1.5">
            <RefreshCw className={"h-4 w-4 " + (loading ? "animate-spin" : "")} /> Refresh
          </button>
        </div>
        <p className="mt-2 text-xs text-white/50">{users.length} user{users.length === 1 ? "" : "s"}</p>
      </div>

      <div className="px-4 pt-3 space-y-2">
        {users.map((u) => (
          <div key={u.id} className="rounded-2xl border border-white/10 bg-white/5 p-3">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <p className="truncate text-sm">{u.full_name || "—"}</p>
                  {u.is_admin && (
                    <span className="rounded-full bg-sky-500/20 px-2 py-0.5 text-[0.65rem] text-sky-300 ring-1 ring-sky-500/40">ADMIN</span>
                  )}
                </div>
                <p className="text-xs text-white/60">{u.mobile}</p>
                <p className="text-[0.7rem] text-white/40 truncate">{u.email}</p>
                <p className="mt-1 text-[0.7rem] text-white/50">
                  Ref: <span className="text-white/80">{u.referral_code}</span>
                  {u.referred_by ? <> · by <span className="text-white/80">{u.referred_by}</span></> : null}
                </p>
              </div>
              <div className="text-right">
                <p className="text-lg tabular-nums">{Number(u.wallet_balance).toLocaleString()}</p>
                <p className="text-[0.65rem] uppercase tracking-wider text-white/50">Wallet UGX</p>
              </div>
            </div>

            <div className="mt-3 grid grid-cols-4 gap-1.5">
              <button onClick={() => adjustBalance(u, 10000)} className="rounded-lg bg-emerald-500/15 text-emerald-300 py-1.5 text-xs ring-1 ring-emerald-500/30">+10k</button>
              <button onClick={() => adjustBalance(u, 50000)} className="rounded-lg bg-emerald-500/15 text-emerald-300 py-1.5 text-xs ring-1 ring-emerald-500/30">+50k</button>
              <button onClick={() => adjustBalance(u, -10000)} className="rounded-lg bg-rose-500/15 text-rose-300 py-1.5 text-xs ring-1 ring-rose-500/30">−10k</button>
              <button onClick={() => setEditing(u)} className="rounded-lg bg-white/10 py-1.5 text-xs ring-1 ring-white/15">Edit</button>
            </div>
            <div className="mt-1.5 grid grid-cols-2 gap-1.5">
              <button onClick={() => toggleAdmin(u)} className="flex items-center justify-center gap-1 rounded-lg bg-white/5 py-1.5 text-xs ring-1 ring-white/15">
                {u.is_admin ? <><ShieldOff className="h-3.5 w-3.5" /> Revoke admin</> : <><Shield className="h-3.5 w-3.5" /> Make admin</>}
              </button>
              <button onClick={() => deleteProfile(u)} className="flex items-center justify-center gap-1 rounded-lg bg-rose-500/15 text-rose-300 py-1.5 text-xs ring-1 ring-rose-500/30">
                <Trash2 className="h-3.5 w-3.5" /> Delete
              </button>
            </div>
          </div>
        ))}
        {!loading && users.length === 0 && (
          <div className="rounded-2xl border border-white/10 bg-white/5 p-8 text-center text-sm text-white/60">
            No users match.
          </div>
        )}
      </div>

      {editing && <EditSheet user={editing} onClose={() => setEditing(null)} onSave={(patch) => saveEdit(editing, patch)} />}
    </div>
  );
}

function EditSheet({ user, onClose, onSave }: { user: AdminUser; onClose: () => void; onSave: (patch: Partial<AdminUser>) => void }) {
  const [full_name, setName] = useState(user.full_name);
  const [mobile, setMobile] = useState(user.mobile);
  const [wallet_balance, setBal] = useState<number>(Number(user.wallet_balance));
  const [referral_code, setCode] = useState(user.referral_code);
  const [referred_by, setRefBy] = useState(user.referred_by ?? "");

  return (
    <div className="fixed inset-0 z-50 bg-black/70" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="absolute inset-x-0 bottom-0 rounded-t-3xl bg-[#0f1520] p-5 text-white ring-1 ring-white/10">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-base">Edit user</h2>
          <button onClick={onClose}><X className="h-5 w-5" /></button>
        </div>
        <div className="space-y-3">
          <Field label="Full name" value={full_name} onChange={setName} />
          <Field label="Mobile" value={mobile} onChange={setMobile} />
          <Field label="Wallet balance (UGX)" value={String(wallet_balance)} onChange={(v) => setBal(Number(v) || 0)} />
          <Field label="Referral code" value={referral_code} onChange={setCode} />
          <Field label="Referred by (code)" value={referred_by} onChange={setRefBy} />
        </div>
        <button
          onClick={() => onSave({ full_name, mobile, wallet_balance, referral_code, referred_by: referred_by || null })}
          className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-sky-500 py-3.5 text-sm"
        >
          <Save className="h-4 w-4" /> Save changes
        </button>
      </div>
    </div>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[0.7rem] uppercase tracking-wider text-white/50">{label}</span>
      <input value={value} onChange={(e) => onChange(e.target.value)} className="w-full rounded-xl bg-white/5 px-3 py-2.5 text-sm outline-none ring-1 ring-white/10 focus:ring-sky-500" />
    </label>
  );
}
