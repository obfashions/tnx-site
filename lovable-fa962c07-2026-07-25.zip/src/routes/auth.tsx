import { createFileRoute, useNavigate, useSearch } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Loader2, Bot } from "lucide-react";
import authBg from "@/assets/auth-mountains.jpg";

const searchSchema = z.object({
  tab: z.enum(["login", "register"]).optional(),
  ref: z.string().optional(),
});

export const Route = createFileRoute("/auth")({
  ssr: false,
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "TNX — Sign in or Register" },
      { name: "description", content: "Create your TNX account with your Uganda mobile number and start earning with AI robots." },
    ],
  }),
  component: AuthPage,
});

function normalizeUgMobile(input: string): string {
  const digits = input.replace(/\D/g, "");
  if (digits.startsWith("256")) return "+" + digits;
  if (digits.startsWith("0")) return "+256" + digits.slice(1);
  if (digits.length === 9 && digits.startsWith("7")) return "+256" + digits;
  return "+256" + digits;
}

function mobileToEmail(mobile: string): string {
  return `u${mobile.replace(/\D/g, "")}@tnxairobots.app`;
}

function AuthPage() {
  const { tab, ref } = useSearch({ from: "/auth" });
  const [mode, setMode] = useState<"login" | "register">(tab ?? "register");
  const navigate = useNavigate();

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) navigate({ to: "/dashboard", replace: true });
    });
  }, [navigate]);

  return (
    <div className="relative min-h-screen overflow-hidden bg-neutral-900">
      {/* Full-bleed background photo */}
      <div
        aria-hidden
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${authBg})` }}
      />
      <div aria-hidden className="absolute inset-0 bg-black/25" />

      <div className="relative z-10 mx-auto flex min-h-screen w-full max-w-md flex-col px-6 pt-10 pb-8">
        {/* Circular brand mark */}
        <div className="mx-auto mb-8 mt-2 flex h-28 w-28 flex-col items-center justify-center rounded-full bg-white/95 shadow-2xl ring-1 ring-white/40 backdrop-blur">
          <Bot className="h-10 w-10 text-neutral-800" strokeWidth={1.4} />
          <span className="mt-1 text-[0.62rem] font-semibold tracking-[0.22em] text-neutral-800">
            TNX·AI
          </span>
        </div>

        {mode === "register" ? (
          <RegisterForm defaultRef={ref} onSwitch={() => setMode("login")} />
        ) : (
          <LoginForm onSwitch={() => setMode("register")} />
        )}
      </div>
    </div>
  );
}

function PillInput({
  prefix,
  ...props
}: { prefix?: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div className="flex items-center gap-3 rounded-full bg-white px-6 py-4 shadow-lg">
      {prefix && (
        <span className="text-[15px] font-semibold text-neutral-900">{prefix}</span>
      )}
      <input
        {...props}
        className="min-w-0 flex-1 border-0 bg-transparent text-[15px] font-normal text-neutral-800 outline-none placeholder:text-neutral-500"
      />
    </div>
  );
}

function PrimaryPill({
  children,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...props}
      className="flex h-14 w-full items-center justify-center rounded-full bg-neutral-900 text-[16px] font-semibold text-white shadow-xl transition active:scale-[0.99] disabled:opacity-70"
    >
      {children}
    </button>
  );
}

function GhostPill({
  children,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...props}
      className="flex h-14 w-full items-center justify-center gap-1 rounded-full bg-white text-[15px] font-normal text-neutral-700 shadow-md"
    >
      {children}
    </button>
  );
}

function LoginForm({ onSwitch }: { onSwitch: () => void }) {
  const [mobile, setMobile] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const normalized = normalizeUgMobile(mobile);
      const email = mobileToEmail(normalized);
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      toast.success("Welcome back");
      sessionStorage.setItem("tnx_just_authed", "1");
      sessionStorage.removeItem("tnx_welcome_shown");
      navigate({ to: "/dashboard", replace: true });
    } catch (err: any) {
      toast.error(err.message ?? "Sign in failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="mt-auto space-y-3.5">
      <PillInput
        prefix="+256"
        value={mobile}
        onChange={(e) => setMobile(e.target.value)}
        placeholder="Please enter your mobile number"
        required
        inputMode="tel"
        autoComplete="tel"
      />
      <PillInput
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Login password"
        required
        autoComplete="current-password"
      />
      <div className="pt-2">
        <PrimaryPill type="submit" disabled={loading}>
          {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : "Log in now"}
        </PrimaryPill>
      </div>
      <GhostPill type="button" onClick={onSwitch}>
        Don't have an account,&nbsp;<span className="font-semibold text-neutral-900">Create one</span>
      </GhostPill>
    </form>
  );
}

function RegisterForm({ defaultRef, onSwitch }: { defaultRef?: string; onSwitch: () => void }) {
  const [form, setForm] = useState({
    mobile: "",
    password: "",
    confirm: "",
    referral: defaultRef ?? "",
  });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const upd =
    (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
      setForm((f) => ({ ...f, [k]: e.target.value }));

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (form.mobile.replace(/\D/g, "").length < 9) return toast.error("Enter a valid Uganda mobile number");
    if (form.password.length < 6) return toast.error("Password must be at least 6 characters");
    if (form.password !== form.confirm) return toast.error("Passwords do not match");
    setLoading(true);
    try {
      const normalized = normalizeUgMobile(form.mobile);
      const email = mobileToEmail(normalized);
      const { error } = await supabase.auth.signUp({
        email,
        password: form.password,
        options: {
          data: {
            mobile: normalized,
            referred_by: form.referral.trim() || null,
          },
        },
      });
      if (error) throw error;
      toast.success("Account created");
      sessionStorage.setItem("tnx_just_authed", "1");
      sessionStorage.removeItem("tnx_welcome_shown");
      navigate({ to: "/dashboard", replace: true });
    } catch (err: any) {
      toast.error(err.message ?? "Registration failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="mt-auto space-y-3.5">
      <PillInput
        prefix="+256"
        value={form.mobile}
        onChange={upd("mobile")}
        placeholder="Please enter your mobile number"
        required
        inputMode="tel"
        autoComplete="tel"
      />
      <PillInput
        type="password"
        value={form.password}
        onChange={upd("password")}
        placeholder="Login password"
        required
        autoComplete="new-password"
      />
      <PillInput
        type="password"
        value={form.confirm}
        onChange={upd("confirm")}
        placeholder="Repeat password"
        required
        autoComplete="new-password"
      />
      <PillInput
        value={form.referral}
        onChange={upd("referral")}
        placeholder="Invitation code"
      />

      <div className="pt-2">
        <PrimaryPill type="submit" disabled={loading}>
          {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : "Create an account now"}
        </PrimaryPill>
      </div>

      <GhostPill type="button" onClick={onSwitch}>
        I already have an account,&nbsp;<span className="font-semibold text-neutral-900">Log in now</span>
      </GhostPill>
    </form>
  );
}
