
CREATE TABLE public.user_investments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_id TEXT NOT NULL,
  plan_name TEXT NOT NULL,
  price NUMERIC NOT NULL,
  daily NUMERIC NOT NULL,
  cycle_days INTEGER NOT NULL,
  days_paid INTEGER NOT NULL DEFAULT 0,
  total_earned NUMERIC NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'running',
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_payout_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.user_investments TO authenticated;
GRANT ALL ON public.user_investments TO service_role;
ALTER TABLE public.user_investments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own investments read" ON public.user_investments FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE TRIGGER user_investments_touch BEFORE UPDATE ON public.user_investments FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE INDEX user_investments_user_status_idx ON public.user_investments(user_id, status);

CREATE OR REPLACE FUNCTION public.accrue_user_earnings(_user_id UUID)
RETURNS TABLE(credited NUMERIC, days_credited INTEGER)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  inv RECORD;
  due_days INTEGER;
  pay_amt NUMERIC;
  total_credit NUMERIC := 0;
  total_days INTEGER := 0;
  i INTEGER;
  ref TEXT;
BEGIN
  FOR inv IN
    SELECT * FROM public.user_investments
    WHERE user_id = _user_id AND status = 'running'
    FOR UPDATE
  LOOP
    due_days := LEAST(
      inv.cycle_days - inv.days_paid,
      GREATEST(0, FLOOR(EXTRACT(EPOCH FROM (now() - inv.started_at)) / 86400)::INTEGER - inv.days_paid)
    );
    IF due_days > 0 THEN
      pay_amt := due_days * inv.daily;
      FOR i IN 1..due_days LOOP
        ref := 'ERN-' || substr(inv.id::text, 1, 8) || '-' || (inv.days_paid + i);
        INSERT INTO public.transactions (user_id, type, amount, currency, phone, reference, status, description)
        VALUES (_user_id, 'earning', inv.daily, 'UGX', '', ref, 'success',
                'Daily payout · ' || inv.plan_name || ' (day ' || (inv.days_paid + i) || '/' || inv.cycle_days || ')')
        ON CONFLICT (reference) DO NOTHING;
      END LOOP;

      UPDATE public.user_investments
         SET days_paid = inv.days_paid + due_days,
             total_earned = inv.total_earned + pay_amt,
             last_payout_at = now(),
             status = CASE WHEN inv.days_paid + due_days >= inv.cycle_days THEN 'completed' ELSE 'running' END
       WHERE id = inv.id;

      UPDATE public.profiles
         SET wallet_balance = COALESCE(wallet_balance, 0) + pay_amt
       WHERE id = _user_id;

      total_credit := total_credit + pay_amt;
      total_days := total_days + due_days;
    END IF;
  END LOOP;

  RETURN QUERY SELECT total_credit, total_days;
END;
$$;

-- Ensure transactions.reference is unique so idempotent inserts are safe
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'transactions_reference_key'
  ) THEN
    ALTER TABLE public.transactions ADD CONSTRAINT transactions_reference_key UNIQUE (reference);
  END IF;
END$$;
