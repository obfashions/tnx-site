
CREATE OR REPLACE FUNCTION public.pay_referral_commissions(_user_id uuid, _amount numeric, _source_ref text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  rates numeric[] := ARRAY[0.10, 0.05, 0.02];
  cur_child uuid := _user_id;
  parent_code text;
  parent_id uuid;
  bonus numeric;
  lvl smallint;
  ref text;
BEGIN
  IF _amount IS NULL OR _amount <= 0 THEN
    RETURN;
  END IF;

  FOR lvl IN 1..3 LOOP
    SELECT referred_by INTO parent_code FROM public.profiles WHERE id = cur_child;
    IF parent_code IS NULL OR parent_code = '' THEN EXIT; END IF;

    SELECT id INTO parent_id FROM public.profiles WHERE referral_code = parent_code;
    IF parent_id IS NULL THEN EXIT; END IF;

    bonus := ROUND(_amount * rates[lvl], 2);
    IF bonus > 0 THEN
      ref := 'REFB-' || substr(parent_id::text, 1, 8) || '-L' || lvl || '-' || _source_ref;

      INSERT INTO public.referral_commissions (user_id, from_user_id, level, amount, source_reference)
      VALUES (parent_id, _user_id, lvl, bonus, _source_ref)
      ON CONFLICT DO NOTHING;

      UPDATE public.profiles
         SET wallet_balance = COALESCE(wallet_balance, 0) + bonus
       WHERE id = parent_id;

      INSERT INTO public.transactions (user_id, type, amount, currency, phone, reference, status, description)
      VALUES (parent_id, 'bonus', bonus, 'UGX', '', ref, 'success',
              'Level ' || lvl || ' referral bonus (' || (rates[lvl] * 100)::int || '%)')
      ON CONFLICT (reference) DO NOTHING;
    END IF;

    cur_child := parent_id;
  END LOOP;
END;
$$;

REVOKE ALL ON FUNCTION public.pay_referral_commissions(uuid, numeric, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.pay_referral_commissions(uuid, numeric, text) TO service_role;
