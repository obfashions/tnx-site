CREATE TYPE public.tx_kind AS ENUM ('deposit','withdraw');
CREATE TYPE public.tx_status AS ENUM ('pending','success','failed');

CREATE TABLE public.transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type public.tx_kind NOT NULL,
  amount NUMERIC(14,2) NOT NULL CHECK (amount > 0),
  currency TEXT NOT NULL DEFAULT 'UGX',
  phone TEXT NOT NULL,
  network TEXT,
  reference TEXT NOT NULL UNIQUE,
  obpay_transaction_id TEXT,
  status public.tx_status NOT NULL DEFAULT 'pending',
  fee NUMERIC(14,2),
  net_amount NUMERIC(14,2),
  description TEXT,
  error_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.transactions TO authenticated;
GRANT ALL ON public.transactions TO service_role;

ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "users select own tx" ON public.transactions
  FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "users insert own tx" ON public.transactions
  FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "admins select all tx" ON public.transactions
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));

CREATE TRIGGER transactions_touch BEFORE UPDATE ON public.transactions
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE INDEX transactions_user_created_idx ON public.transactions(user_id, created_at DESC);
CREATE INDEX transactions_status_idx ON public.transactions(status) WHERE status='pending';