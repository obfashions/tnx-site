ALTER TYPE public.tx_kind ADD VALUE IF NOT EXISTS 'earning';
ALTER TYPE public.tx_kind ADD VALUE IF NOT EXISTS 'bonus';