
-- Trigger-only functions: no direct callers needed
REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.touch_updated_at() FROM PUBLIC, anon, authenticated;

-- Server-only helpers (invoked from privileged server code / triggers)
REVOKE ALL ON FUNCTION public.pay_referral_commissions(uuid, numeric, text) FROM PUBLIC, anon, authenticated;

-- User-callable RPCs: keep authenticated only, drop anon/public
REVOKE ALL ON FUNCTION public.get_direct_referrals(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.get_team_overview(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.accrue_user_earnings(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.admin_list_users(text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.admin_list_support_threads() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_direct_referrals(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_team_overview(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.accrue_user_earnings(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_list_users(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_list_support_threads() TO authenticated;

-- has_role is used inside RLS policies; policies evaluate as the querying role,
-- so authenticated still needs EXECUTE. Drop anon/public.
REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;
