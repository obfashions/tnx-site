
-- Referral commissions ledger
CREATE TABLE public.referral_commissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  from_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  level smallint NOT NULL CHECK (level BETWEEN 1 AND 3),
  amount numeric NOT NULL DEFAULT 0,
  source text NOT NULL DEFAULT 'investment',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_referral_commissions_user ON public.referral_commissions(user_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.referral_commissions TO authenticated;
GRANT ALL ON public.referral_commissions TO service_role;
ALTER TABLE public.referral_commissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owner reads own commissions" ON public.referral_commissions
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- Team overview: counts + bonuses per level for the caller
CREATE OR REPLACE FUNCTION public.get_team_overview(_user_id uuid)
RETURNS TABLE (level smallint, size bigint, bonus numeric)
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  my_code text;
BEGIN
  IF _user_id IS NULL OR _user_id <> auth.uid() THEN
    RAISE EXCEPTION 'not authorized';
  END IF;
  SELECT referral_code INTO my_code FROM public.profiles WHERE id = _user_id;

  RETURN QUERY
  WITH RECURSIVE tree AS (
    SELECT p.id, p.referral_code, 1::smallint AS lvl
      FROM public.profiles p
     WHERE p.referred_by = my_code
    UNION ALL
    SELECT p.id, p.referral_code, (t.lvl + 1)::smallint
      FROM public.profiles p
      JOIN tree t ON p.referred_by = t.referral_code
     WHERE t.lvl < 3
  )
  SELECT lv.level,
         COALESCE(cnt.size, 0) AS size,
         COALESCE(bn.bonus, 0) AS bonus
    FROM (VALUES (1::smallint), (2::smallint), (3::smallint)) AS lv(level)
    LEFT JOIN (
      SELECT lvl AS level, COUNT(*)::bigint AS size FROM tree GROUP BY lvl
    ) cnt ON cnt.level = lv.level
    LEFT JOIN (
      SELECT rc.level, SUM(rc.amount)::numeric AS bonus
        FROM public.referral_commissions rc
       WHERE rc.user_id = _user_id
       GROUP BY rc.level
    ) bn ON bn.level = lv.level
   ORDER BY lv.level;
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_team_overview(uuid) TO authenticated;

-- List direct (level 1) referrals for the caller
CREATE OR REPLACE FUNCTION public.get_direct_referrals(_user_id uuid)
RETURNS TABLE (id uuid, full_name text, mobile text, created_at timestamptz)
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  my_code text;
BEGIN
  IF _user_id IS NULL OR _user_id <> auth.uid() THEN
    RAISE EXCEPTION 'not authorized';
  END IF;
  SELECT referral_code INTO my_code FROM public.profiles WHERE id = _user_id;

  RETURN QUERY
  SELECT p.id, p.full_name,
         -- mask mobile for privacy: keep +256 and last 3
         CASE WHEN length(p.mobile) > 6
              THEN substr(p.mobile, 1, 4) || '••••' || right(p.mobile, 3)
              ELSE p.mobile END AS mobile,
         p.created_at
    FROM public.profiles p
   WHERE p.referred_by = my_code
   ORDER BY p.created_at DESC
   LIMIT 100;
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_direct_referrals(uuid) TO authenticated;
