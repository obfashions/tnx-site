
-- ============ app_settings ============
CREATE TABLE public.app_settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid REFERENCES auth.users(id)
);

GRANT SELECT ON public.app_settings TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.app_settings TO authenticated;
GRANT ALL ON public.app_settings TO service_role;

ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "settings_read_auth" ON public.app_settings
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "settings_admin_write" ON public.app_settings
  FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "settings_admin_update" ON public.app_settings
  FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "settings_admin_delete" ON public.app_settings
  FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER app_settings_touch
  BEFORE UPDATE ON public.app_settings
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

INSERT INTO public.app_settings (key, value) VALUES
  ('welcome_bonus', '{"enabled": false, "amount": 0, "message": "Welcome to TNX AI Robots! Your account is ready."}'::jsonb),
  ('whatsapp_group_url', '"https://chat.whatsapp.com/"'::jsonb),
  ('withdraw', '{"min": 5000, "max": 2000000, "fee_percent": 3, "fee_min": 500}'::jsonb),
  ('deposit', '{"min": 5000, "max": 5000000}'::jsonb);

-- ============ investment_plans ============
CREATE TABLE public.investment_plans (
  id text PRIMARY KEY,
  series text NOT NULL,
  code text NOT NULL,
  name text NOT NULL,
  price numeric NOT NULL,
  daily numeric NOT NULL,
  cycle_days integer NOT NULL,
  lock_days integer NOT NULL DEFAULT 0,
  total numeric NOT NULL,
  image_url text,
  sold_out boolean NOT NULL DEFAULT false,
  active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.investment_plans TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.investment_plans TO authenticated;
GRANT ALL ON public.investment_plans TO service_role;

ALTER TABLE public.investment_plans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "plans_read_auth" ON public.investment_plans
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "plans_admin_insert" ON public.investment_plans
  FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "plans_admin_update" ON public.investment_plans
  FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "plans_admin_delete" ON public.investment_plans
  FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER investment_plans_touch
  BEFORE UPDATE ON public.investment_plans
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

INSERT INTO public.investment_plans (id, series, code, name, price, daily, cycle_days, lock_days, total, sold_out, sort_order) VALUES
  ('w-1','W','W-1','ATLAS Mini',   50000,    3000,   25, 25,    75000, false, 10),
  ('w-2','W','W-2','ATLAS Core',   150000,   9600,   25, 25,    240000, false, 11),
  ('w-3','W','W-3','ATLAS Pro',    300000,   20000,  25, 25,    500000, false, 12),
  ('w-4','W','W-4','ATLAS Max',    600000,   42000,  25, 25,    1050000, false, 13),
  ('w-5','W','W-5','ATLAS Ultra',  1200000,  87000,  25, 25,    2175000, false, 14),
  ('w-6','W','W-6','ATLAS Titan',  2500000,  187500, 25, 25,    4687500, false, 15),
  ('k-1','K','K-1','NOVA Node',    100000,   6000,   30, 30,    180000, false, 20),
  ('k-2','K','K-2','NOVA Stack',   300000,   19500,  30, 30,    585000, false, 21),
  ('k-3','K','K-3','NOVA Cluster', 700000,   47000,  30, 30,    1410000, false, 22),
  ('k-4','K','K-4','NOVA Grid',    1500000,  105000, 30, 30,    3150000, false, 23),
  ('k-5','K','K-5','NOVA Prime',   3000000,  220000, 30, 30,    6600000, false, 24),
  ('a-1','A','A-1','ANCHOR-1',     30000,    2000,   20, 0,     40000, false, 30),
  ('a-2','A','A-2','ANCHOR-2',     100000,   7000,   20, 0,     140000, false, 31),
  ('a-3','A','A-3','ANCHOR-3',     300000,   22000,  20, 0,     440000, false, 32),
  ('a-4','A','A-4','ANCHOR-4',     700000,   53000,  20, 0,     1060000, false, 33),
  ('a-5','A','A-5','ANCHOR-5',     1500000,  116000, 20, 0,     2320000, false, 34),
  ('a-6','A','A-6','ANCHOR-6',     4000000,  320000, 20, 0,     6400000, false, 35),
  ('s-1','S','S-1','SENTINEL-1',   5000000,  240000, 45, 45,    10800000, true, 40),
  ('s-2','S','S-2','SENTINEL-2',   10000000, 500000, 45, 45,    22500000, true, 41),
  ('s-3','S','S-3','SENTINEL-3',   25000000, 1300000,45, 45,    58500000, true, 42);

-- ============ Update handle_new_user to apply welcome bonus ============
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  bonus_cfg jsonb;
  bonus_enabled boolean := false;
  bonus_amount numeric := 0;
BEGIN
  INSERT INTO public.profiles (id, full_name, mobile, email, referred_by)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'mobile', ''),
    NEW.email,
    NEW.raw_user_meta_data->>'referred_by'
  );
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user');

  SELECT value INTO bonus_cfg FROM public.app_settings WHERE key = 'welcome_bonus';
  IF bonus_cfg IS NOT NULL THEN
    bonus_enabled := COALESCE((bonus_cfg->>'enabled')::boolean, false);
    bonus_amount  := COALESCE((bonus_cfg->>'amount')::numeric, 0);
  END IF;

  IF bonus_enabled AND bonus_amount > 0 THEN
    UPDATE public.profiles
       SET wallet_balance = COALESCE(wallet_balance, 0) + bonus_amount
     WHERE id = NEW.id;
    INSERT INTO public.transactions (user_id, type, amount, currency, phone, reference, status, description)
    VALUES (NEW.id, 'bonus', bonus_amount, 'UGX', '', 'BONUS-'||substr(NEW.id::text,1,8)||'-'||extract(epoch from now())::bigint, 'success', 'Welcome bonus');
  END IF;

  RETURN NEW;
END;
$function$;
