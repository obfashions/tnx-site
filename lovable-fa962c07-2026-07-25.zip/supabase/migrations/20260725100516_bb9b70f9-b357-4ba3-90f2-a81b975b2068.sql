CREATE TABLE public.support_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  from_admin boolean NOT NULL DEFAULT false,
  sender_id uuid,
  body text NOT NULL,
  read_by_user boolean NOT NULL DEFAULT false,
  read_by_admin boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_support_messages_user_created ON public.support_messages(user_id, created_at);

GRANT SELECT, INSERT, UPDATE ON public.support_messages TO authenticated;
GRANT ALL ON public.support_messages TO service_role;

ALTER TABLE public.support_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "user reads own thread" ON public.support_messages
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "user sends own thread" ON public.support_messages
  FOR INSERT TO authenticated
  WITH CHECK (
    (user_id = auth.uid() AND from_admin = false AND sender_id = auth.uid())
    OR (public.has_role(auth.uid(), 'admin') AND from_admin = true AND sender_id = auth.uid())
  );

CREATE POLICY "mark read" ON public.support_messages
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

ALTER PUBLICATION supabase_realtime ADD TABLE public.support_messages;
ALTER TABLE public.support_messages REPLICA IDENTITY FULL;

-- Admin helper: list all users with a support thread, latest message and unread count
CREATE OR REPLACE FUNCTION public.admin_list_support_threads()
RETURNS TABLE(
  user_id uuid,
  full_name text,
  mobile text,
  last_body text,
  last_at timestamptz,
  last_from_admin boolean,
  unread_admin bigint
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'not authorized';
  END IF;
  RETURN QUERY
  WITH latest AS (
    SELECT DISTINCT ON (sm.user_id) sm.user_id, sm.body, sm.created_at, sm.from_admin
      FROM public.support_messages sm
     ORDER BY sm.user_id, sm.created_at DESC
  ),
  unread AS (
    SELECT sm.user_id, COUNT(*)::bigint AS n
      FROM public.support_messages sm
     WHERE sm.from_admin = false AND sm.read_by_admin = false
     GROUP BY sm.user_id
  )
  SELECT p.id, p.full_name, p.mobile,
         l.body, l.created_at, l.from_admin,
         COALESCE(u.n, 0)
    FROM latest l
    JOIN public.profiles p ON p.id = l.user_id
    LEFT JOIN unread u ON u.user_id = l.user_id
   ORDER BY l.created_at DESC
   LIMIT 500;
END $$;