## Goal
Give the admin console (`+256762201984`) live control over: investment plans, welcome bonus, WhatsApp group link, withdraw limits + fee %, and recharge (deposit) limits — with the app reading these values instead of hardcoded constants.

## Schema (one migration)

**`app_settings`** — single-row key/value store (one row per key, JSON value). Seeded with:
- `welcome_bonus` → `{ enabled: true, amount: 0, message: "..." }`
- `whatsapp_group_url` → `"https://chat.whatsapp.com/..."`
- `withdraw` → `{ min: 5000, max: 2000000, fee_percent: 3, fee_min: 500 }`
- `deposit` → `{ min: 5000, max: 5000000 }`

**`investment_plans`** — replaces the hardcoded `PLANS` array:
`id (text pk, e.g. "w-1"), series (text), name, price, daily_payout, cycle_days, total_return, image_url, sold_out (bool), active (bool), sort_order`.

Both: RLS — anyone authenticated can `SELECT`; only `has_role(auth.uid(),'admin')` can `INSERT/UPDATE/DELETE`. GRANTs to authenticated + service_role. Seed `investment_plans` with the current 21 tiers so nothing regresses.

Welcome bonus applied via `handle_new_user()` trigger: if `enabled`, credit `wallet_balance` with `amount` and insert a `transactions` row (`type='bonus'`).

## Admin UI

New route `/_authenticated/admin/settings` (linked from admin console header):
- **General** tab: welcome bonus (toggle + amount + message), WhatsApp URL, withdraw min/max/fee%/fee_min, deposit min/max.
- **Plans** tab: table of plans with inline edit (price, daily, cycle, total, sold_out, active), add-new row, delete.

Save writes back to the two tables; audit entries in `admin_actions`.

## App wiring (read from DB)

- `src/lib/plans-data.ts` → replace hardcoded `PLAN_PRICES` + `withdrawFee` with a `getPlan(id)` / `getWithdrawSettings()` fetch from `app_settings`/`investment_plans`. Server functions (`obpay.functions.ts` `invest` / `initiateWithdraw`) read fee + limits from DB.
- `robots.index.tsx` + `robots.$id.tsx` → fetch plans from `investment_plans` (react-query), keep same UI.
- `MoneySheet.tsx` → read min/max + fee from `app_settings`; show fee dynamically.
- `WelcomePopup.tsx` → read WhatsApp URL + welcome bonus copy from `app_settings`.

## Out of scope
Per-user limits, currency switching, image uploads (admin pastes image URL for now).

## Technical notes
- Single JSON-value settings table keeps future keys additive without new migrations.
- Plan images stay as remote URLs; existing bundled assets keep working as fallbacks.
- Fee still enforced server-side in `initiateWithdraw` — client value is display-only.
